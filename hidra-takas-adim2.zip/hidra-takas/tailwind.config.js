/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // Admin panelinden değiştirilebilen vurgu renkleri (CSS değişkeni)
        brand: "rgb(var(--brand) / <alpha-value>)",
        accent: "rgb(var(--accent) / <alpha-value>)",
        bg: "#07090d",
        surface: "#0d121a",
        card: "#111823",
        line: "#1d2736",
        ink: "#e8edf5",
        muted: "#93a0b4",
      },
      fontFamily: {
        sans: [
          "ui-sans-serif",
          "system-ui",
          "-apple-system",
          "Segoe UI",
          "Roboto",
          "Helvetica Neue",
          "Arial",
          "sans-serif",
        ],
      },
      boxShadow: {
        card: "0 1px 0 0 rgb(255 255 255 / 0.03) inset, 0 12px 32px -12px rgb(0 0 0 / 0.6)",
        glow: "0 0 0 1px rgb(var(--brand) / 0.5), 0 8px 32px -8px rgb(var(--brand) / 0.55)",
      },
      keyframes: {
        rise: {
          from: { opacity: "0", transform: "translateY(10px)" },
          to: { opacity: "1", transform: "translateY(0)" },
        },
      },
      animation: { rise: "rise .5s ease-out both" },
    },
  },
  plugins: [],
};
