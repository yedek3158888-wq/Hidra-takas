-- =====================================================================
-- ORJHIDRA MARKET - Başlangıç şeması (PostgreSQL / Supabase)
-- Supabase Dashboard > SQL Editor içinde tek seferde çalıştırın.
-- Not: "users" tablosu Supabase'in auth.users tablosudur; "profiles" ile eşlenir.
-- Not: "references" PostgreSQL'de ayrılmış kelime olduğu için tablo adı
--      trade_references'tır.
-- =====================================================================

create extension if not exists pgcrypto;
create extension if not exists pg_trgm;

-- ---------------------------------------------------------------------
-- Yardımcı: updated_at
-- ---------------------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

-- ---------------------------------------------------------------------
-- PROFILES
-- ---------------------------------------------------------------------
create table public.profiles (
  id           uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Oyuncu'
               check (char_length(display_name) between 2 and 32),
  avatar_icon  text not null default 'shield'
               check (avatar_icon in ('shield','bolt','star','ball','crown','flame')),
  role         text not null default 'user' check (role in ('user','admin')),
  is_banned    boolean not null default false,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create trigger trg_profiles_updated before update on public.profiles
  for each row execute function public.set_updated_at();

-- Yetki yardımcıları (security definer: RLS özyinelemesini önler)
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin' and not is_banned
  );
$$;

create or replace function public.is_active_user()
returns boolean language sql stable security definer set search_path = public as $$
  select auth.uid() is not null and not exists (
    select 1 from public.profiles where id = auth.uid() and is_banned
  );
$$;

-- Yeni kayıtta profil oluştur. Rol HER ZAMAN 'user' olur.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  v_name text;
begin
  v_name := left(btrim(coalesce(new.raw_user_meta_data->>'display_name', '')), 32);
  if char_length(v_name) < 2 then
    v_name := 'Oyuncu' || substr(replace(new.id::text, '-', ''), 1, 4);
  end if;
  insert into public.profiles (id, display_name) values (new.id, v_name);
  return new;
end $$;

create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Rol / yasak alanlarını yetkisiz değiştirmeyi engelle
create or replace function public.guard_profile_update()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.role is distinct from old.role or new.is_banned is distinct from old.is_banned then
    -- auth.uid() null ise SQL Editor / servis rolü (güvenilir kurulum yolu) demektir
    if auth.uid() is not null then
      if not public.is_admin() then
        raise exception 'Bu alanı değiştirme yetkiniz yok' using errcode = '42501';
      end if;
      if old.id = auth.uid() then
        raise exception 'Kendi rolünüzü veya durumunuzu değiştiremezsiniz' using errcode = '42501';
      end if;
    end if;
  end if;
  new.id := old.id;
  return new;
end $$;
create trigger trg_profiles_guard before update on public.profiles
  for each row execute function public.guard_profile_update();

-- Herkese açık profil görünümü (yalnızca güvenli alanlar)
create view public.public_profiles as
  select id, display_name, avatar_icon from public.profiles where not is_banned;

-- ---------------------------------------------------------------------
-- LISTINGS
-- ---------------------------------------------------------------------
create sequence public.listing_no_seq start 1001;

create table public.listings (
  id               uuid primary key default gen_random_uuid(),
  listing_no       bigint not null unique default nextval('public.listing_no_seq'),
  title            text not null check (char_length(title) between 3 and 120),
  platform         text not null default 'Belirtilmedi' check (char_length(platform) <= 40),
  team_strength    integer check (team_strength between 0 and 5000),
  featured_players text not null default '' check (char_length(featured_players) <= 2000),
  description      text not null default '' check (char_length(description) <= 5000),
  trade_terms      text not null default '' check (char_length(trade_terms) <= 3000),
  wanted_features  text not null default '' check (char_length(wanted_features) <= 3000),
  price            numeric(12,2) check (price is null or price >= 0),
  currency         text not null default 'TRY' check (char_length(currency) = 3),
  status           text not null default 'beklemede'
                   check (status in ('aktif','beklemede','takas_tamamlandi','yayindan_kaldirildi')),
  tags             text[] not null default '{}' check (cardinality(tags) <= 10),
  is_featured      boolean not null default false,
  created_by       uuid references auth.users(id) on delete set null,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);
create index listings_status_idx    on public.listings (status);
create index listings_featured_idx  on public.listings (is_featured) where is_featured;
create index listings_created_idx   on public.listings (created_at desc);
create index listings_strength_idx  on public.listings (team_strength);
create index listings_tags_idx      on public.listings using gin (tags);
create index listings_title_trgm    on public.listings using gin (title gin_trgm_ops);
create trigger trg_listings_updated before update on public.listings
  for each row execute function public.set_updated_at();

create table public.listing_images (
  id         uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.listings(id) on delete cascade,
  path       text not null check (char_length(path) <= 300),
  alt        text not null default '' check (char_length(alt) <= 200),
  position   integer not null default 0,
  created_at timestamptz not null default now()
);
create index listing_images_listing_idx on public.listing_images (listing_id, position);

-- ---------------------------------------------------------------------
-- REVIEWS (1-5 yıldız, kullanıcı başına ilan başına bir adet)
-- ---------------------------------------------------------------------
create table public.reviews (
  id         uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.listings(id) on delete cascade,
  user_id    uuid not null references public.profiles(id) on delete cascade,
  rating     smallint not null check (rating between 1 and 5),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (listing_id, user_id)
);
create trigger trg_reviews_updated before update on public.reviews
  for each row execute function public.set_updated_at();

create view public.listing_rating_stats as
  select listing_id, round(avg(rating)::numeric, 2) as avg_rating, count(*)::int as review_count
  from public.reviews group by listing_id;

-- ---------------------------------------------------------------------
-- COMMENTS
-- ---------------------------------------------------------------------
create table public.comments (
  id              uuid primary key default gen_random_uuid(),
  listing_id      uuid not null references public.listings(id) on delete cascade,
  user_id         uuid not null references public.profiles(id) on delete cascade,
  body            text not null check (char_length(btrim(body)) between 3 and 1000),
  status          text not null default 'visible' check (status in ('visible','hidden','removed')),
  moderation_note text check (moderation_note is null or char_length(moderation_note) <= 500),
  helpful_count   integer not null default 0 check (helpful_count >= 0),
  edited_at       timestamptz,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);
create index comments_listing_idx on public.comments (listing_id, created_at desc);
create index comments_user_idx    on public.comments (user_id, created_at desc);
create index comments_status_idx  on public.comments (status);
create trigger trg_comments_updated before update on public.comments
  for each row execute function public.set_updated_at();

-- Spam koruması (sunucu/veritabanı tarafı): saatte en fazla 5 yorum, aynı metin 24 saat tekrar edilemez
create or replace function public.comments_before_insert()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  new.body := btrim(new.body);
  new.status := 'visible';
  new.helpful_count := 0;
  new.moderation_note := null;
  if (select count(*) from public.comments
        where user_id = new.user_id and created_at > now() - interval '1 hour') >= 5 then
    raise exception 'Çok fazla yorum gönderdiniz. Lütfen biraz bekleyin.' using errcode = 'P0001';
  end if;
  if exists (select 1 from public.comments
        where user_id = new.user_id and listing_id = new.listing_id
          and lower(body) = lower(new.body) and created_at > now() - interval '24 hours') then
    raise exception 'Bu yorumu zaten gönderdiniz.' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_comments_before_insert before insert on public.comments
  for each row execute function public.comments_before_insert();

-- Yorum güncellemede: normal kullanıcı yalnızca metni değiştirebilir
create or replace function public.comments_before_update()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and not public.is_admin() then
    new.status := old.status;
    new.helpful_count := old.helpful_count;
    new.moderation_note := old.moderation_note;
    new.user_id := old.user_id;
    new.listing_id := old.listing_id;
    new.body := btrim(new.body);
    if new.body is distinct from old.body then
      new.edited_at := now();
    end if;
  end if;
  return new;
end $$;
create trigger trg_comments_before_update before update on public.comments
  for each row execute function public.comments_before_update();

create table public.comment_votes (
  comment_id uuid not null references public.comments(id) on delete cascade,
  user_id    uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (comment_id, user_id)
);

create or replace function public.comment_votes_count()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    update public.comments set helpful_count = helpful_count + 1 where id = new.comment_id;
  elsif tg_op = 'DELETE' then
    update public.comments set helpful_count = greatest(helpful_count - 1, 0) where id = old.comment_id;
  end if;
  return null;
end $$;
create trigger trg_comment_votes_count after insert or delete on public.comment_votes
  for each row execute function public.comment_votes_count();

-- ---------------------------------------------------------------------
-- TRADE_REFERENCES (referanslar) + görselleri
-- ---------------------------------------------------------------------
create table public.trade_references (
  id                uuid primary key default gen_random_uuid(),
  title             text not null check (char_length(title) between 3 and 120),
  summary           text not null default '' check (char_length(summary) <= 1000),
  trade_date        date,
  listing_id        uuid references public.listings(id) on delete set null,
  source            text not null default 'user' check (source in ('admin','user')),
  -- user_declared: kullanıcı beyanı | admin_verified: yönetici işlemi doğruladı
  verification      text not null default 'user_declared'
                    check (verification in ('user_declared','admin_verified')),
  status            text not null default 'pending'
                    check (status in ('pending','approved','rejected','removed')),
  consent_confirmed boolean not null default false,
  review_note       text check (review_note is null or char_length(review_note) <= 500),
  submitted_by      uuid references auth.users(id) on delete set null,
  reviewed_by       uuid references auth.users(id) on delete set null,
  reviewed_at       timestamptz,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  -- Kullanıcı gönderimleri gizlilik onayı olmadan kaydedilemez
  check (source = 'admin' or consent_confirmed)
);
create index trade_references_status_idx on public.trade_references (status, created_at desc);
create index trade_references_listing_idx on public.trade_references (listing_id);
create trigger trg_trade_references_updated before update on public.trade_references
  for each row execute function public.set_updated_at();

create table public.reference_images (
  id           uuid primary key default gen_random_uuid(),
  reference_id uuid not null references public.trade_references(id) on delete cascade,
  -- Bekleyen gönderimler özel kovada, onaylananlar herkese açık kovada tutulur
  bucket       text not null default 'reference-pending'
               check (bucket in ('reference-pending','reference-public')),
  path         text not null check (char_length(path) <= 300),
  position     integer not null default 0,
  created_at   timestamptz not null default now()
);
create index reference_images_ref_idx on public.reference_images (reference_id, position);

-- ---------------------------------------------------------------------
-- CONTACT_MESSAGES / REPORTS (yalnızca sunucu üzerinden eklenir)
-- ---------------------------------------------------------------------
create table public.contact_messages (
  id         uuid primary key default gen_random_uuid(),
  nickname   text not null check (char_length(nickname) between 2 and 40),
  message    text not null check (char_length(message) between 5 and 2000),
  listing_no bigint,
  status     text not null default 'unread' check (status in ('unread','read','archived','closed')),
  ip_hash    text,          -- yalnızca hız sınırı için tuzlanmış özet; ham IP saklanmaz
  created_at timestamptz not null default now()
);
create index contact_messages_status_idx on public.contact_messages (status, created_at desc);
create index contact_messages_iphash_idx on public.contact_messages (ip_hash, created_at desc);

create table public.reports (
  id          uuid primary key default gen_random_uuid(),
  target_type text not null check (target_type in ('listing','comment')),
  listing_id  uuid references public.listings(id) on delete cascade,
  comment_id  uuid references public.comments(id) on delete cascade,
  reason      text not null check (reason in ('sahte','uygunsuz','spam','kisisel_bilgi','diger')),
  details     text check (details is null or char_length(details) <= 500),
  reporter_id uuid references auth.users(id) on delete set null,
  ip_hash     text,
  status      text not null default 'open' check (status in ('open','reviewed','dismissed')),
  created_at  timestamptz not null default now(),
  check ((target_type = 'listing' and listing_id is not null)
      or (target_type = 'comment' and comment_id is not null))
);
create index reports_status_idx on public.reports (status, created_at desc);
create index reports_iphash_idx on public.reports (ip_hash, created_at desc);

-- Saklama kuralı: iletişim mesajları 90 gün, kapatılmış şikayetler 180 gün sonra silinir.
-- Supabase'de pg_cron ile günlük çalıştırın (bkz. README).
create or replace function public.purge_old_records()
returns void language sql security definer set search_path = public as $$
  delete from public.contact_messages where created_at < now() - interval '90 days';
  delete from public.reports where status <> 'open' and created_at < now() - interval '180 days';
$$;
revoke all on function public.purge_old_records() from public, anon, authenticated;

-- ---------------------------------------------------------------------
-- SITE_SETTINGS
-- ---------------------------------------------------------------------
create table public.site_settings (
  key        text primary key check (char_length(key) <= 64),
  value      jsonb not null,
  updated_at timestamptz not null default now(),
  updated_by uuid references auth.users(id) on delete set null
);
create trigger trg_site_settings_updated before update on public.site_settings
  for each row execute function public.set_updated_at();

-- ---------------------------------------------------------------------
-- ADMIN_AUDIT_LOGS (yalnızca eklenir; güncelleme/silme politikası yoktur)
-- ---------------------------------------------------------------------
create table public.admin_audit_logs (
  id         bigint generated always as identity primary key,
  actor_id   uuid references auth.users(id) on delete set null,
  action     text not null,
  entity     text not null,
  entity_id  text,
  details    jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index admin_audit_logs_created_idx on public.admin_audit_logs (created_at desc);

-- Yönetici bir tabloda değişiklik yaptığında otomatik kayıt (kişisel veri yazılmaz)
create or replace function public.log_admin_change()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  v jsonb;
begin
  if auth.uid() is null or not public.is_admin() then
    return null;
  end if;
  v := to_jsonb(coalesce(new, old));
  insert into public.admin_audit_logs (actor_id, action, entity, entity_id, details)
  values (
    auth.uid(), tg_op, tg_table_name, coalesce(v->>'id', v->>'key'),
    jsonb_strip_nulls(jsonb_build_object(
      'title', v->>'title', 'status', v->>'status', 'role', v->>'role',
      'is_banned', v->>'is_banned', 'listing_no', v->>'listing_no'))
  );
  return null;
end $$;

create trigger audit_listings   after insert or update or delete on public.listings
  for each row execute function public.log_admin_change();
create trigger audit_comments   after update or delete on public.comments
  for each row execute function public.log_admin_change();
create trigger audit_references after insert or update or delete on public.trade_references
  for each row execute function public.log_admin_change();
create trigger audit_settings   after insert or update or delete on public.site_settings
  for each row execute function public.log_admin_change();
create trigger audit_profiles   after update on public.profiles
  for each row execute function public.log_admin_change();
create trigger audit_reports    after update or delete on public.reports
  for each row execute function public.log_admin_change();
create trigger audit_messages   after update or delete on public.contact_messages
  for each row execute function public.log_admin_change();

-- ---------------------------------------------------------------------
-- Herkese açık, doğrulanabilir istatistikler (yalnızca gerçek sayımlar)
-- ---------------------------------------------------------------------
create or replace function public.public_stats()
returns jsonb language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'active_listings',    (select count(*) from public.listings where status = 'aktif'),
    'completed_listings', (select count(*) from public.listings where status = 'takas_tamamlandi'),
    'approved_references',(select count(*) from public.trade_references where status = 'approved'),
    'visible_comments',   (select count(*) from public.comments where status = 'visible')
  );
$$;

-- =====================================================================
-- ROW LEVEL SECURITY
-- =====================================================================
alter table public.profiles          enable row level security;
alter table public.listings          enable row level security;
alter table public.listing_images    enable row level security;
alter table public.reviews           enable row level security;
alter table public.comments          enable row level security;
alter table public.comment_votes     enable row level security;
alter table public.trade_references  enable row level security;
alter table public.reference_images  enable row level security;
alter table public.contact_messages  enable row level security;
alter table public.reports           enable row level security;
alter table public.site_settings     enable row level security;
alter table public.admin_audit_logs  enable row level security;

-- profiles
create policy profiles_select on public.profiles for select to authenticated
  using (id = auth.uid() or public.is_admin());
create policy profiles_update on public.profiles for update to authenticated
  using (id = auth.uid() or public.is_admin())
  with check (id = auth.uid() or public.is_admin());

-- listings (yayından kaldırılanlar yalnızca admine görünür)
create policy listings_select on public.listings for select to anon, authenticated
  using (status <> 'yayindan_kaldirildi' or public.is_admin());
create policy listings_admin_write on public.listings for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

create policy listing_images_select on public.listing_images for select to anon, authenticated
  using (exists (select 1 from public.listings l where l.id = listing_id));
create policy listing_images_admin_write on public.listing_images for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- reviews
create policy reviews_select on public.reviews for select to anon, authenticated using (true);
create policy reviews_insert on public.reviews for insert to authenticated
  with check (user_id = auth.uid() and public.is_active_user()
              and exists (select 1 from public.listings l where l.id = listing_id and l.status <> 'yayindan_kaldirildi'));
create policy reviews_update on public.reviews for update to authenticated
  using (user_id = auth.uid() and public.is_active_user())
  with check (user_id = auth.uid());
create policy reviews_delete on public.reviews for delete to authenticated
  using (user_id = auth.uid() or public.is_admin());

-- comments
create policy comments_select on public.comments for select to anon, authenticated
  using (status = 'visible' or user_id = auth.uid() or public.is_admin());
create policy comments_insert on public.comments for insert to authenticated
  with check (user_id = auth.uid() and public.is_active_user()
              and exists (select 1 from public.listings l where l.id = listing_id and l.status <> 'yayindan_kaldirildi'));
create policy comments_update on public.comments for update to authenticated
  using ((user_id = auth.uid() and public.is_active_user()) or public.is_admin())
  with check ((user_id = auth.uid()) or public.is_admin());
create policy comments_delete on public.comments for delete to authenticated
  using (user_id = auth.uid() or public.is_admin());

create policy comment_votes_select on public.comment_votes for select to authenticated
  using (user_id = auth.uid());
create policy comment_votes_insert on public.comment_votes for insert to authenticated
  with check (user_id = auth.uid() and public.is_active_user());
create policy comment_votes_delete on public.comment_votes for delete to authenticated
  using (user_id = auth.uid());

-- trade_references
create policy refs_select on public.trade_references for select to anon, authenticated
  using (status = 'approved' or submitted_by = auth.uid() or public.is_admin());
create policy refs_insert_user on public.trade_references for insert to authenticated
  with check (
    public.is_admin()
    or (submitted_by = auth.uid() and public.is_active_user()
        and source = 'user' and status = 'pending' and verification = 'user_declared'
        and consent_confirmed and reviewed_by is null and reviewed_at is null)
  );
create policy refs_admin_update on public.trade_references for update to authenticated
  using (public.is_admin()) with check (public.is_admin());
create policy refs_admin_delete on public.trade_references for delete to authenticated
  using (public.is_admin());

create policy ref_images_select on public.reference_images for select to anon, authenticated
  using (exists (select 1 from public.trade_references r where r.id = reference_id));
create policy ref_images_insert on public.reference_images for insert to authenticated
  with check (
    public.is_admin()
    or (bucket = 'reference-pending' and exists (
          select 1 from public.trade_references r
          where r.id = reference_id and r.submitted_by = auth.uid() and r.status = 'pending'))
  );
create policy ref_images_admin_update on public.reference_images for update to authenticated
  using (public.is_admin()) with check (public.is_admin());
create policy ref_images_admin_delete on public.reference_images for delete to authenticated
  using (public.is_admin());

-- contact_messages & reports: yalnızca admin okur/yönetir; ekleme sunucu (servis anahtarı) ile
create policy contact_admin_all on public.contact_messages for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
create policy reports_admin_all on public.reports for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- site_settings: herkes okur (içerik herkese açıktır), yalnızca admin yazar
create policy settings_select on public.site_settings for select to anon, authenticated using (true);
create policy settings_admin_write on public.site_settings for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- admin_audit_logs: yalnızca admin okur; güncelleme/silme politikası yok
create policy audit_admin_select on public.admin_audit_logs for select to authenticated
  using (public.is_admin());

-- ---------------------------------------------------------------------
-- Yetkiler (RLS ile birlikte çalışır)
-- ---------------------------------------------------------------------
grant usage on schema public to anon, authenticated;
grant select on public.listings, public.listing_images, public.reviews, public.comments,
                public.trade_references, public.reference_images, public.site_settings,
                public.public_profiles, public.listing_rating_stats to anon;
grant select, insert, update, delete on public.profiles, public.listings, public.listing_images,
  public.reviews, public.comments, public.comment_votes, public.trade_references,
  public.reference_images, public.contact_messages, public.reports, public.site_settings to authenticated;
revoke insert, delete on public.profiles from authenticated;
grant select on public.admin_audit_logs, public.public_profiles, public.listing_rating_stats to authenticated;
grant usage on sequence public.listing_no_seq to authenticated;
grant execute on function public.public_stats() to anon, authenticated;
grant execute on function public.is_admin() to anon, authenticated;
grant execute on function public.is_active_user() to anon, authenticated;

-- ---------------------------------------------------------------------
-- STORAGE (görseller veritabanından ayrı, erişim kurallı kovalarda)
-- ---------------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values
  ('listing-images',    'listing-images',    true,  5242880, array['image/jpeg','image/png','image/webp']),
  ('reference-public',  'reference-public',  true,  5242880, array['image/jpeg','image/png','image/webp']),
  ('reference-pending', 'reference-pending', false, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

create policy storage_public_read on storage.objects for select to anon, authenticated
  using (bucket_id in ('listing-images','reference-public'));

create policy storage_admin_write on storage.objects for all to authenticated
  using (bucket_id in ('listing-images','reference-public','reference-pending') and public.is_admin())
  with check (bucket_id in ('listing-images','reference-public','reference-pending') and public.is_admin());

create policy storage_pending_upload on storage.objects for insert to authenticated
  with check (bucket_id = 'reference-pending' and public.is_active_user()
              and (storage.foldername(name))[1] = auth.uid()::text);
create policy storage_pending_read_own on storage.objects for select to authenticated
  using (bucket_id = 'reference-pending' and (storage.foldername(name))[1] = auth.uid()::text);

-- ---------------------------------------------------------------------
-- Varsayılan site ayarları (yalnızca yapılandırma; sahte içerik DEĞİLDİR)
-- ---------------------------------------------------------------------
insert into public.site_settings (key, value) values
  ('brand_name',  '"ORJHIDRA MARKET"'),
  ('slogan',      '"eFootball hesap takası topluluğu"'),
  ('description', '"Hesap ilanlarını inceleyin, yorumları ve referansları okuyun, takas için doğrudan iletişime geçin."'),
  ('telegram',   '""'),
  ('instagram',  '""'),
  ('threads',    '""'),
  ('colors',     '{"brand":"#2f6bff","accent":"#22d3ee"}'),
  ('sections',   '{"featured":true,"latest":true,"references":true,"steps":true,"faq":true,"risk":true}')
on conflict (key) do nothing;
