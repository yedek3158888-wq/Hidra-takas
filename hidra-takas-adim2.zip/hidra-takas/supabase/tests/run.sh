#!/usr/bin/env bash
# Kullanım: PGHOST=... PGPORT=... PGUSER=postgres bash supabase/tests/run.sh
# Boş bir yerel PostgreSQL gerekir (Supabase'in auth/storage yapısı taklit edilir).
set -e
cd "$(dirname "$0")"
psql -q -c "drop database if exists hidra_test" -c "create database hidra_test" postgres
psql -d hidra_test -q -v ON_ERROR_STOP=1 -f 00_supabase_stub.sql
psql -d hidra_test -q -v ON_ERROR_STOP=1 -f ../migrations/0001_init.sql
psql -d hidra_test -q -t -A -f 01_policy_tests.sql 2>&1 | grep -E '^(PASS|FAIL|[0-9]+\|[0-9]+|psql:)'
