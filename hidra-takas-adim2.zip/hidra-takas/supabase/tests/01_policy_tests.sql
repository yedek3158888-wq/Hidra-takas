\set ON_ERROR_STOP off
-- kullanıcılar
insert into auth.users(id,email,raw_user_meta_data) values
 ('aaaaaaaa-0000-0000-0000-000000000001','admin@x.test','{"display_name":"Yonetici"}'),
 ('bbbbbbbb-0000-0000-0000-000000000002','u1@x.test','{"display_name":"Oyuncu Bir"}'),
 ('cccccccc-0000-0000-0000-000000000003','u2@x.test','{}'),
 ('dddddddd-0000-0000-0000-000000000004','banned@x.test','{"display_name":"x"}');
select t.chk('profil otomatik olustu, rol=user', (select count(*)=4 and bool_and(role='user') from profiles));
select t.chk('gecersiz ad icin yedek ad uretildi', (select display_name like 'Oyuncu%' from profiles where id='cccccccc-0000-0000-0000-000000000003'));
update profiles set role='admin' where id='aaaaaaaa-0000-0000-0000-000000000001';  -- guvenilir kurulum yolu (SQL Editor)
select t.chk('SQL Editor ile admin atama calisti', (select role='admin' from profiles where id='aaaaaaaa-0000-0000-0000-000000000001'));

-- ---------- U1 ----------
set role authenticated; set request.jwt.claim.sub='bbbbbbbb-0000-0000-0000-000000000002';
do $$ begin begin update profiles set role='admin' where id=auth.uid(); perform t.chk('U1 kendini admin yapamaz', (select role='user' from profiles where id=auth.uid()));
  exception when others then perform t.chk('U1 kendini admin yapamaz', true); end; end $$;
update profiles set display_name='Yeni Ad' where id=auth.uid();
select t.chk('U1 gorunen adini degistirebilir', (select display_name='Yeni Ad' from profiles where id=auth.uid()));
select t.chk('U1 baska profilleri goremez', (select count(*)=1 from profiles));
do $$ begin begin insert into listings(title) values ('Hile ilan'); perform t.chk('U1 ilan ekleyemez', false); exception when others then perform t.chk('U1 ilan ekleyemez', true); end; end $$;
reset role;

-- ---------- ADMIN: ilanlar ----------
set role authenticated; set request.jwt.claim.sub='aaaaaaaa-0000-0000-0000-000000000001';
insert into listings(title,status,team_strength,tags) values ('Aktif Hesap','aktif',3200,'{"mavi"}'),('Bekleyen Hesap','beklemede',2800,'{}'),('Gizli Hesap','yayindan_kaldirildi',2000,'{}');
select t.chk('listing_no 1001den baslar ve benzersiz', (select min(listing_no)>=1001 and count(distinct listing_no)=3 from listings));
select t.chk('admin tum ilanlari gorur', (select count(*)=3 from listings));
select t.chk('denetim kaydi otomatik yazildi', (select count(*)>=3 from admin_audit_logs where entity='listings'));
do $$ begin begin update profiles set role='user' where id=auth.uid(); perform t.chk('admin kendi rolunu degistiremez', (select role='admin' from profiles where id=auth.uid())); exception when others then perform t.chk('admin kendi rolunu degistiremez', true); end; end $$;
do $$ begin begin delete from admin_audit_logs; perform t.chk('denetim kaydi silinemez', (select count(*)>0 from admin_audit_logs)); exception when others then perform t.chk('denetim kaydi silinemez', true); end; end $$;
reset role;

-- ---------- ANON ----------
set role anon; reset request.jwt.claim.sub;
select t.chk('anon yalnizca yayindaki ilanlari gorur', (select count(*)=2 from listings));
do $$ begin begin perform * from profiles; perform t.chk('anon profiles okuyamaz', false); exception when others then perform t.chk('anon profiles okuyamaz', true); end; end $$;
select t.chk('anon public_profiles okuyabilir (rol yok)', (select count(*)=4 from public_profiles));
do $$ begin begin insert into contact_messages(nickname,message) values ('abc','mesaj mesaj'); perform t.chk('anon dogrudan mesaj ekleyemez', false); exception when others then perform t.chk('anon dogrudan mesaj ekleyemez', true); end; end $$;
do $$ begin begin perform * from admin_audit_logs; perform t.chk('anon denetim kaydini okuyamaz', false); exception when others then perform t.chk('anon denetim kaydini okuyamaz', true); end; end $$;
select t.chk('anon ayarlari okuyabilir', (select count(*)>=8 from site_settings));
select t.chk('public_stats dogru sayar', (select (public_stats()->>'active_listings')::int=1 and (public_stats()->>'approved_references')::int=0));
reset role;

reset role;
create table t.ids as select id from listings where title='Gizli Hesap'; grant select on t.ids to public;
-- ---------- U1: yorum / degerlendirme ----------
set role authenticated; set request.jwt.claim.sub='bbbbbbbb-0000-0000-0000-000000000002';
insert into comments(listing_id,user_id,body) select id,auth.uid(),'Harika hesap gibi duruyor' from listings where title='Aktif Hesap';
select t.chk('U1 yorum ekledi', (select count(*)=1 from comments where user_id=auth.uid()));
do $$ begin begin insert into comments(listing_id,user_id,body) select id,auth.uid(),'harika hesap gibi duruyor' from listings where title='Aktif Hesap'; perform t.chk('tekrarlanan yorum engellendi', false); exception when others then perform t.chk('tekrarlanan yorum engellendi', true); end; end $$;
do $$ begin begin insert into comments(listing_id,user_id,body) select id,'cccccccc-0000-0000-0000-000000000003','baska adina yorum' from listings where title='Aktif Hesap'; perform t.chk('baskasi adina yorum yazilamaz', false); exception when others then perform t.chk('baskasi adina yorum yazilamaz', true); end; end $$;
do $$ begin begin insert into comments(listing_id,user_id,body) select id,auth.uid(),'gizli ilana yorum' from t.ids; perform t.chk('kaldirilan ilana yorum yazilamaz', false); exception when others then perform t.chk('kaldirilan ilana yorum yazilamaz', true); end; end $$;
update comments set status='hidden', helpful_count=99, body='Duzenlendi yorum' where user_id=auth.uid();
select t.chk('kullanici durum/yardimci sayisini degistiremez, metni duzenleyebilir', (select status='visible' and helpful_count=0 and body='Duzenlendi yorum' and edited_at is not null from comments where user_id=auth.uid()));
do $$ declare i int; begin for i in 1..4 loop insert into comments(listing_id,user_id,body) select id,auth.uid(),'yorum numara '||i from listings where title='Aktif Hesap'; end loop;
  begin insert into comments(listing_id,user_id,body) select id,auth.uid(),'altinci yorum' from listings where title='Aktif Hesap'; perform t.chk('saatlik yorum siniri', false); exception when others then perform t.chk('saatlik yorum siniri', true); end; end $$;
insert into reviews(listing_id,user_id,rating) select id,auth.uid(),5 from listings where title='Aktif Hesap';
do $$ begin begin insert into reviews(listing_id,user_id,rating) select id,auth.uid(),4 from listings where title='Aktif Hesap'; perform t.chk('ayni ilana ikinci puan engellendi', false); exception when others then perform t.chk('ayni ilana ikinci puan engellendi', true); end; end $$;
do $$ begin begin insert into reviews(listing_id,user_id,rating) select id,auth.uid(),6 from listings where title='Bekleyen Hesap'; perform t.chk('puan 1-5 disinda reddedildi', false); exception when others then perform t.chk('puan 1-5 disinda reddedildi', true); end; end $$;
reset role;
select t.chk('puan ortalamasi gercek veriden', (select avg_rating=5 and review_count=1 from listing_rating_stats));

-- ---------- U2 baska kullanicinin verisine dokunamaz ----------
set role authenticated; set request.jwt.claim.sub='cccccccc-0000-0000-0000-000000000003';
update comments set body='Ele gecirildi' where user_id='bbbbbbbb-0000-0000-0000-000000000002';
delete from comments where user_id='bbbbbbbb-0000-0000-0000-000000000002';
reset role;
select t.chk('U2 baskasinin yorumunu degistiremez/silemez', (select count(*)=5 and bool_and(body<>'Ele gecirildi') from comments));

-- ---------- Moderasyon ----------
set role authenticated; set request.jwt.claim.sub='aaaaaaaa-0000-0000-0000-000000000001';
update comments set status='hidden', moderation_note='uygunsuz' where body='Duzenlendi yorum';
select t.chk('admin yorumu gizleyebilir', (select count(*)=1 from comments where status='hidden'));
reset role;
set role anon; reset request.jwt.claim.sub;
select t.chk('gizli yorum anona gorunmez', (select count(*)=4 from comments));
reset role;
set role authenticated; set request.jwt.claim.sub='aaaaaaaa-0000-0000-0000-000000000001';
update comments set status='visible' where status='hidden';
select t.chk('admin yorumu tekrar yayimlayabilir', (select count(*)=5 from comments where status='visible'));
reset role;

-- ---------- Referanslar ----------
set role authenticated; set request.jwt.claim.sub='bbbbbbbb-0000-0000-0000-000000000002';
insert into trade_references(title,summary,submitted_by,source,consent_confirmed) values ('Takas Ref 1','ozet',auth.uid(),'user',true);
select t.chk('U1 referans gonderdi (bekliyor)', (select status='pending' and verification='user_declared' from trade_references where submitted_by=auth.uid()));
do $$ begin begin insert into trade_references(title,submitted_by,source,consent_confirmed) values ('Onaysiz',auth.uid(),'user',false); perform t.chk('gizlilik onayi olmadan referans gonderilemez', false); exception when others then perform t.chk('gizlilik onayi olmadan referans gonderilemez', true); end; end $$;
do $$ begin begin insert into trade_references(title,submitted_by,source,consent_confirmed,status,verification) values ('Kendini onayladi',auth.uid(),'user',true,'approved','admin_verified'); perform t.chk('kullanici kendi referansini onaylayamaz', false); exception when others then perform t.chk('kullanici kendi referansini onaylayamaz', true); end; end $$;
reset role;
set role anon; reset request.jwt.claim.sub; select t.chk('bekleyen referans anona gorunmez', (select count(*)=0 from trade_references)); reset role;
set role authenticated; set request.jwt.claim.sub='cccccccc-0000-0000-0000-000000000003';
select t.chk('U2 baskasinin bekleyen referansini goremez', (select count(*)=0 from trade_references)); reset role;
set role authenticated; set request.jwt.claim.sub='bbbbbbbb-0000-0000-0000-000000000002';
update trade_references set status='approved' where submitted_by=auth.uid();
select t.chk('kullanici referans durumunu degistiremez', (select status='pending' from trade_references where submitted_by=auth.uid())); reset role;
set role authenticated; set request.jwt.claim.sub='aaaaaaaa-0000-0000-0000-000000000001';
update trade_references set status='approved', reviewed_by=auth.uid(), reviewed_at=now();
reset role;
set role anon; reset request.jwt.claim.sub; select t.chk('onaylanan referans herkese gorunur', (select count(*)=1 from trade_references)); select t.chk('stats onayli referansi sayar', (select (public_stats()->>'approved_references')::int=1)); reset role;

-- ---------- Ayarlar / mesajlar ----------
set role authenticated; set request.jwt.claim.sub='bbbbbbbb-0000-0000-0000-000000000002';
update site_settings set value='"HACK"' where key='brand_name';
select t.chk('kullanici ayar degistiremez', (select value='"ORJHIDRA MARKET"'::jsonb from site_settings where key='brand_name'));
select t.chk('kullanici denetim kaydini goremez', (select count(*)=0 from admin_audit_logs));
select t.chk('kullanici iletisim mesajlarini goremez', (select count(*)=0 from contact_messages));
reset role;
insert into contact_messages(nickname,message,listing_no) values ('deneme','merhaba mesaj',1001);  -- servis rolu yolu
set role authenticated; set request.jwt.claim.sub='aaaaaaaa-0000-0000-0000-000000000001';
select t.chk('admin iletisim mesajini gorur', (select count(*)=1 from contact_messages));
update contact_messages set status='read';
update site_settings set value='"ORJHIDRA MARKET 2"' where key='brand_name';
select t.chk('admin ayar degistirebilir + kayit duser', (select count(*)=1 from admin_audit_logs where entity='site_settings' and action='UPDATE'));
select t.chk('mesaj durumu guncellenebilir', (select status='read' from contact_messages));
-- admin baska kullaniciyi yonetici yapar / yasaklar
update profiles set role='admin' where id='cccccccc-0000-0000-0000-000000000003';
update profiles set is_banned=true where id='dddddddd-0000-0000-0000-000000000004';
select t.chk('admin rol verebilir ve kullaniciyi yasaklayabilir', (select (select role from profiles where id='cccccccc-0000-0000-0000-000000000003')='admin' and (select is_banned from profiles where id='dddddddd-0000-0000-0000-000000000004')));
reset role;
set role authenticated; set request.jwt.claim.sub='dddddddd-0000-0000-0000-000000000004';
do $$ begin begin insert into comments(listing_id,user_id,body) select id,auth.uid(),'yasakli yorum' from listings where title='Aktif Hesap'; perform t.chk('yasakli kullanici yorum yazamaz', false); exception when others then perform t.chk('yasakli kullanici yorum yazamaz', true); end; end $$;
reset role;

-- ---------- Storage ----------
set role authenticated; set request.jwt.claim.sub='bbbbbbbb-0000-0000-0000-000000000002';
insert into storage.objects(bucket_id,name) values ('reference-pending','bbbbbbbb-0000-0000-0000-000000000002/a.jpg');
select t.chk('U1 kendi klasorune ozel kovaya yukler', (select count(*)=1 from storage.objects));
do $$ begin begin insert into storage.objects(bucket_id,name) values ('reference-pending','cccccccc-0000-0000-0000-000000000003/a.jpg'); perform t.chk('baska klasore yukleme engellendi', false); exception when others then perform t.chk('baska klasore yukleme engellendi', true); end; end $$;
do $$ begin begin insert into storage.objects(bucket_id,name) values ('listing-images','x.jpg'); perform t.chk('kullanici ilan gorseli yukleyemez', false); exception when others then perform t.chk('kullanici ilan gorseli yukleyemez', true); end; end $$;
reset role;
set role authenticated; set request.jwt.claim.sub='aaaaaaaa-0000-0000-0000-000000000001';
insert into storage.objects(bucket_id,name) values ('listing-images','ilan/1.jpg');
select t.chk('admin ilan gorseli yukler; bekleyen gorseli okur', (select count(*)=2 from storage.objects));
reset role;
set role anon; reset request.jwt.claim.sub; select t.chk('anon ozel kovayi goremez, acik kovayi gorur', (select count(*)=1 and bool_and(bucket_id='listing-images') from storage.objects)); reset role;

select case when ok then 'PASS' else 'FAIL' end as sonuc, name from t.res order by ok, name;
select count(*) filter (where ok) as gecen, count(*) filter (where not ok) as kalan from t.res;
