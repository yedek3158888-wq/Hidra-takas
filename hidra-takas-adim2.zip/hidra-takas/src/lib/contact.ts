export type Channel = "telegram" | "instagram" | "threads";

export interface ChannelInfo {
  key: Channel;
  label: string;
  url: string;
  host: string;
}

const HOSTS: Record<Channel, { label: string; host: string; base: string }> = {
  telegram: { label: "Telegram", host: "t.me", base: "https://t.me/" },
  instagram: { label: "Instagram", host: "instagram.com", base: "https://www.instagram.com/" },
  threads: { label: "Threads", host: "threads.net", base: "https://www.threads.net/@" },
};

const ALLOWED_HOSTS: Record<Channel, string[]> = {
  telegram: ["t.me", "telegram.me", "telegram.dev"],
  instagram: ["instagram.com", "www.instagram.com"],
  threads: ["threads.net", "www.threads.net", "threads.com", "www.threads.com"],
};

/**
 * Kullanıcı adı ("@ad" veya "ad") ya da tam adres kabul eder.
 * Yalnızca ilgili platformun alan adlarına izin verir (açık yönlendirme/XSS önlemi).
 * Geçersizse null döner.
 */
export function buildChannel(channel: Channel, raw: string | undefined | null): ChannelInfo | null {
  const value = (raw ?? "").trim();
  if (!value) return null;
  const meta = HOSTS[channel];

  if (/^https?:\/\//i.test(value)) {
    try {
      const u = new URL(value);
      if (u.protocol !== "https:" && u.protocol !== "http:") return null;
      if (!ALLOWED_HOSTS[channel].includes(u.hostname.toLowerCase())) return null;
      return { key: channel, label: meta.label, url: `https://${u.hostname}${u.pathname}${u.search}`, host: u.hostname };
    } catch {
      return null;
    }
  }

  const handle = value.replace(/^@/, "");
  if (!/^[A-Za-z0-9._]{3,64}$/.test(handle)) return null;
  return { key: channel, label: meta.label, url: `${meta.base}${handle}`, host: meta.host };
}
