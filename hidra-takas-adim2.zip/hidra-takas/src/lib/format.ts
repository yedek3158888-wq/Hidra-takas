import type { ListingStatus } from "./types";

const dateFmt = new Intl.DateTimeFormat("tr-TR", { dateStyle: "medium", timeZone: "Europe/Istanbul" });
const numFmt = new Intl.NumberFormat("tr-TR");

export function formatDate(value: string | null | undefined): string {
  if (!value) return "";
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? "" : dateFmt.format(d);
}

export function formatNumber(value: number | null | undefined): string {
  return typeof value === "number" ? numFmt.format(value) : "";
}

/** Fiyat yalnızca gerçekten girilmişse gösterilir; aksi halde boş döner. */
export function formatPrice(price: number | null | undefined, currency = "TRY"): string {
  if (typeof price !== "number") return "";
  try {
    return new Intl.NumberFormat("tr-TR", { style: "currency", currency, maximumFractionDigits: 0 }).format(price);
  } catch {
    return `${numFmt.format(price)} ${currency}`;
  }
}

export const STATUS_LABEL: Record<ListingStatus, string> = {
  aktif: "Aktif",
  beklemede: "Beklemede",
  takas_tamamlandi: "Takas Tamamlandı",
  yayindan_kaldirildi: "Yayından Kaldırıldı",
};

export function listingNo(n: number): string {
  return `#${n}`;
}
