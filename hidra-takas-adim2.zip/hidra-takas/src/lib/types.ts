export type ListingStatus =
  | "aktif"
  | "beklemede"
  | "takas_tamamlandi"
  | "yayindan_kaldirildi";

export interface ListingImage {
  path: string;
  alt: string;
  position: number;
}

export interface Listing {
  id: string;
  listing_no: number;
  title: string;
  platform: string;
  team_strength: number | null;
  status: ListingStatus;
  tags: string[];
  is_featured: boolean;
  price: number | null;
  currency: string;
  created_at: string;
  updated_at: string;
  listing_images: ListingImage[];
}

export type Verification = "user_declared" | "admin_verified";

export interface TradeReference {
  id: string;
  title: string;
  summary: string;
  trade_date: string | null;
  verification: Verification;
  created_at: string;
  reference_images: { bucket: string; path: string; position: number }[];
}

export interface PublicStats {
  active_listings: number;
  completed_listings: number;
  approved_references: number;
  visible_comments: number;
}
