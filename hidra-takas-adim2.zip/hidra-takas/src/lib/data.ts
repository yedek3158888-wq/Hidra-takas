import { getPublicClient } from "./supabase";
import type { Listing, PublicStats, TradeReference } from "./types";

const LISTING_COLUMNS =
  "id, listing_no, title, platform, team_strength, status, tags, is_featured, price, currency, created_at, updated_at, listing_images(path, alt, position)";

export interface Result<T> {
  data: T;
  /** Veritabanı yapılandırılmamış ya da sorgu hata verdiyse true */
  unavailable: boolean;
}

function sortImages(l: Listing): Listing {
  return {
    ...l,
    listing_images: [...(l.listing_images ?? [])].sort((a, b) => a.position - b.position),
  };
}

export async function getFeaturedListings(limit = 3): Promise<Result<Listing[]>> {
  const client = getPublicClient();
  if (!client) return { data: [], unavailable: true };
  const { data, error } = await client
    .from("listings")
    .select(LISTING_COLUMNS)
    .eq("is_featured", true)
    .in("status", ["aktif", "beklemede"])
    .order("created_at", { ascending: false })
    .limit(limit);
  if (error) return { data: [], unavailable: true };
  return { data: ((data ?? []) as unknown as Listing[]).map(sortImages), unavailable: false };
}

export async function getLatestListings(limit = 6): Promise<Result<Listing[]>> {
  const client = getPublicClient();
  if (!client) return { data: [], unavailable: true };
  const { data, error } = await client
    .from("listings")
    .select(LISTING_COLUMNS)
    .in("status", ["aktif", "beklemede"])
    .order("created_at", { ascending: false })
    .limit(limit);
  if (error) return { data: [], unavailable: true };
  return { data: ((data ?? []) as unknown as Listing[]).map(sortImages), unavailable: false };
}

export interface ListingPage {
  items: Listing[];
  total: number;
}

export async function searchListings(opts: { q?: string; page: number; pageSize: number }): Promise<Result<ListingPage>> {
  const client = getPublicClient();
  if (!client) return { data: { items: [], total: 0 }, unavailable: true };
  const from = (opts.page - 1) * opts.pageSize;
  let query = client
    .from("listings")
    .select(LISTING_COLUMNS, { count: "exact" })
    .neq("status", "yayindan_kaldirildi")
    .order("is_featured", { ascending: false })
    .order("created_at", { ascending: false })
    .range(from, from + opts.pageSize - 1);
  const q = (opts.q ?? "").trim().slice(0, 80);
  if (q) {
    // % ve _ joker karakterlerini kaçır
    query = query.ilike("title", `%${q.replace(/[\\%_]/g, (m) => `\\${m}`)}%`);
  }
  const { data, error, count } = await query;
  if (error) return { data: { items: [], total: 0 }, unavailable: true };
  return {
    data: { items: ((data ?? []) as unknown as Listing[]).map(sortImages), total: count ?? 0 },
    unavailable: false,
  };
}

export async function getApprovedReferences(limit = 4): Promise<Result<TradeReference[]>> {
  const client = getPublicClient();
  if (!client) return { data: [], unavailable: true };
  const { data, error } = await client
    .from("trade_references")
    .select("id, title, summary, trade_date, verification, created_at, reference_images(bucket, path, position)")
    .eq("status", "approved")
    .order("created_at", { ascending: false })
    .limit(limit);
  if (error) return { data: [], unavailable: true };
  const items = ((data ?? []) as unknown as TradeReference[]).map((r) => ({
    ...r,
    reference_images: [...(r.reference_images ?? [])]
      .filter((i) => i.bucket === "reference-public")
      .sort((a, b) => a.position - b.position),
  }));
  return { data: items, unavailable: false };
}

export async function getPublicStats(): Promise<Result<PublicStats | null>> {
  const client = getPublicClient();
  if (!client) return { data: null, unavailable: true };
  const { data, error } = await client.rpc("public_stats");
  if (error || !data) return { data: null, unavailable: true };
  const s = data as Partial<PublicStats>;
  return {
    data: {
      active_listings: Number(s.active_listings ?? 0),
      completed_listings: Number(s.completed_listings ?? 0),
      approved_references: Number(s.approved_references ?? 0),
      visible_comments: Number(s.visible_comments ?? 0),
    },
    unavailable: false,
  };
}
