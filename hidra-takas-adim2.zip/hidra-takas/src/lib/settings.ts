import { cache } from "react";
import { getPublicClient } from "./supabase";
import { buildChannel, type ChannelInfo } from "./contact";

export interface FaqItem {
  q: string;
  a: string;
}

export interface SiteSettings {
  brand_name: string;
  slogan: string;
  description: string;
  logo_url: string;
  favicon_url: string;
  telegram: string;
  instagram: string;
  threads: string;
  contact_text: string;
  footer_text: string;
  colors: { brand: string; accent: string };
  sections: {
    featured: boolean;
    latest: boolean;
    references: boolean;
    steps: boolean;
    faq: boolean;
    risk: boolean;
  };
  faq: FaqItem[];
}

export const DEFAULT_FAQ: FaqItem[] = [
  {
    q: "Bu site resmî bir eFootball veya Konami hizmeti mi?",
    a: "Hayır. Bu site Konami Digital Entertainment ile bağlantılı değildir; bağımsız bir topluluk ilan panosudur.",
  },
  {
    q: "Site takas işlemine aracılık ediyor mu?",
    a: "Hayır. Site yalnızca ilanları ve iletişim kanallarını gösterir. Ödeme, hesap devri veya emanet hizmeti sunmaz. Her görüşme ve işlem taraflar arasındadır.",
  },
  {
    q: "İlanlardaki bilgiler doğrulanıyor mu?",
    a: "İlan bilgileri ilan sahibinin beyanına dayanır. Site, hesapların gerçekliğini veya devredilebilirliğini otomatik olarak garanti etmez.",
  },
  {
    q: "Sizden şifre veya doğrulama kodu istenir mi?",
    a: "Hayır. Bu site hiçbir koşulda oyun şifresi, kurtarma kodu veya doğrulama kodu istemez. Böyle bir talep gelirse yanıt vermeyin ve bildirin.",
  },
  {
    q: "Hesap takası oyunun koşullarına aykırı olabilir mi?",
    a: "Evet. Hesap paylaşımı veya devri oyun sağlayıcısının kullanım koşullarıyla çelişebilir ve hesabın kalıcı olarak kaybedilmesine yol açabilir. Tüm riski kendiniz değerlendirmelisiniz.",
  },
];

export const DEFAULT_SETTINGS: SiteSettings = {
  brand_name: "ORJHIDRA MARKET",
  slogan: "eFootball hesap takası topluluğu",
  description:
    "Hesap ilanlarını inceleyin, yorumları ve referansları okuyun, takas için doğrudan iletişime geçin.",
  logo_url: "",
  favicon_url: "",
  telegram: "",
  instagram: "",
  threads: "",
  contact_text: "Sorularınız için aşağıdaki kanallardan bize ulaşabilirsiniz.",
  footer_text: "",
  colors: { brand: "#2f6bff", accent: "#22d3ee" },
  sections: { featured: true, latest: true, references: true, steps: true, faq: true, risk: true },
  faq: DEFAULT_FAQ,
};

const HEX = /^#[0-9a-fA-F]{6}$/;

function str(v: unknown, fallback: string, max = 500): string {
  return typeof v === "string" ? v.slice(0, max) : fallback;
}

/** Veritabanından gelen ham ayarları doğrulayarak varsayılanlarla birleştirir. */
export function mergeSettings(rows: { key: string; value: unknown }[]): SiteSettings {
  const map = new Map(rows.map((r) => [r.key, r.value]));
  const d = DEFAULT_SETTINGS;

  const colorsRaw = map.get("colors") as Partial<SiteSettings["colors"]> | undefined;
  const sectionsRaw = map.get("sections") as Partial<SiteSettings["sections"]> | undefined;
  const faqRaw = map.get("faq");

  const faq =
    Array.isArray(faqRaw) && faqRaw.length > 0
      ? faqRaw
          .filter((x): x is FaqItem => !!x && typeof x.q === "string" && typeof x.a === "string")
          .slice(0, 20)
          .map((x) => ({ q: x.q.slice(0, 200), a: x.a.slice(0, 1500) }))
      : d.faq;

  return {
    brand_name: str(map.get("brand_name"), d.brand_name, 60) || d.brand_name,
    slogan: str(map.get("slogan"), d.slogan, 160),
    description: str(map.get("description"), d.description, 400),
    logo_url: str(map.get("logo_url"), "", 500),
    favicon_url: str(map.get("favicon_url"), "", 500),
    telegram: str(map.get("telegram"), "", 200),
    instagram: str(map.get("instagram"), "", 200),
    threads: str(map.get("threads"), "", 200),
    contact_text: str(map.get("contact_text"), d.contact_text, 500),
    footer_text: str(map.get("footer_text"), "", 500),
    colors: {
      brand: colorsRaw?.brand && HEX.test(colorsRaw.brand) ? colorsRaw.brand : d.colors.brand,
      accent: colorsRaw?.accent && HEX.test(colorsRaw.accent) ? colorsRaw.accent : d.colors.accent,
    },
    sections: {
      featured: sectionsRaw?.featured ?? true,
      latest: sectionsRaw?.latest ?? true,
      references: sectionsRaw?.references ?? true,
      steps: sectionsRaw?.steps ?? true,
      faq: sectionsRaw?.faq ?? true,
      risk: sectionsRaw?.risk ?? true,
    },
    faq,
  };
}

/** Aynı istekte metadata ve layout tek sorgu paylaşır. */
export const getSettings = cache(async (): Promise<SiteSettings> => {
  const client = getPublicClient();
  if (!client) return DEFAULT_SETTINGS;
  try {
    const { data, error } = await client.from("site_settings").select("key, value");
    if (error || !data) return DEFAULT_SETTINGS;
    return mergeSettings(data as { key: string; value: unknown }[]);
  } catch {
    return DEFAULT_SETTINGS;
  }
});

export function getChannels(s: SiteSettings): {
  telegram: ChannelInfo | null;
  instagram: ChannelInfo | null;
  threads: ChannelInfo | null;
} {
  return {
    telegram: buildChannel("telegram", s.telegram),
    instagram: buildChannel("instagram", s.instagram),
    threads: buildChannel("threads", s.threads),
  };
}

/** "#2f6bff" -> "47 107 255" (Tailwind alpha değişkeni biçimi) */
export function hexToTriplet(hex: string): string {
  const h = HEX.test(hex) ? hex : "#2f6bff";
  const n = parseInt(h.slice(1), 16);
  return `${(n >> 16) & 255} ${(n >> 8) & 255} ${n & 255}`;
}
