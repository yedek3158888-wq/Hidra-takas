import { createClient, type SupabaseClient } from "@supabase/supabase-js";

/**
 * Herkese açık (anon) istemci. Yalnızca RLS izin verdiği verileri okur.
 * Ortam değişkenleri yoksa null döner; sayfalar bunu "kurulum gerekli" olarak gösterir.
 */
export function getPublicClient(): SupabaseClient | null {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !key) return null;
  return createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

export const isSupabaseConfigured = (): boolean =>
  Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY);

function encodePath(path: string): string {
  return path.split("/").map(encodeURIComponent).join("/");
}

/** Herkese açık kovadaki dosyanın adresi. */
export function publicStorageUrl(bucket: string, path: string): string {
  const base = process.env.NEXT_PUBLIC_SUPABASE_URL ?? "";
  return `${base}/storage/v1/object/public/${bucket}/${encodePath(path)}`;
}
