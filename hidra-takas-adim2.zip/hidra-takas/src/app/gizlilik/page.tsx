import type { Metadata } from "next";
import { LegalPage } from "@/components/LegalPage";

export const metadata: Metadata = {
  title: "Gizlilik Politikası ve Çerezler",
  alternates: { canonical: "/gizlilik" },
};

export default function PrivacyPage() {
  return (
    <LegalPage title="Gizlilik Politikası ve Çerezler" updated="Taslak">
      <p>Bu metin, sitenin hangi verileri neden işlediğini açıklamayı amaçlayan bir taslaktır.</p>

      <h2>İşlenen veriler</h2>
      <ul>
        <li>Hesap oluşturursanız: e-posta adresi, görünen ad ve profil simgesi.</li>
        <li>Yorum ve değerlendirmeler: yazdığınız metin ve verdiğiniz puan.</li>
        <li>Referans gönderimi: yüklediğiniz görseller, açıklama ve gizlilik onayınız.</li>
        <li>İletişim/şikâyet formları: rumuz, mesaj ve isteğe bağlı ilan numarası. Spam önleme için IP adresinin ham hali değil, tuzlanmış bir özeti kısa süre tutulur.</li>
      </ul>

      <h2>Almadığımız veriler</h2>
      <p>Site hiçbir koşulda oyun şifresi, kurtarma kodu veya doğrulama kodu istemez. Bunları form, yorum veya referans görsellerinde paylaşmayın.</p>

      <h2>Saklama süresi</h2>
      <ul>
        <li>İletişim mesajları en fazla 90 gün saklanır.</li>
        <li>İncelenmiş şikâyet kayıtları en fazla 180 gün saklanır.</li>
        <li>Hesabınız silindiğinde profiliniz, yorumlarınız ve değerlendirmeleriniz de silinir. Yayınlanmış referanslarınızdaki kişisel bağlantı kaldırılır.</li>
      </ul>

      <h2>Hizmet sağlayıcılar</h2>
      <p>Veritabanı, kimlik doğrulama ve dosya depolama için Supabase; barındırma için Vercel kullanılır. Bu sağlayıcılar kendi gizlilik politikalarına tabidir.</p>

      <h2>Çerezler</h2>
      <p>Site yalnızca oturum açmanızı sürdürmek için zorunlu çerezleri kullanır. Reklam veya takip amaçlı çerez kullanılmaz. Giriş yapmazsanız çerez bırakılmaz.</p>

      <h2>Haklarınız</h2>
      <p>Verilerinize erişim, düzeltme veya silme talebinizi sitedeki iletişim kanalları üzerinden iletebilirsiniz.</p>
    </LegalPage>
  );
}
