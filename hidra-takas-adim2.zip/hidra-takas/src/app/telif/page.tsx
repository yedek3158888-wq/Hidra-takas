import type { Metadata } from "next";
import { LegalPage } from "@/components/LegalPage";

export const metadata: Metadata = {
  title: "Telif ve Marka Bildirimi",
  alternates: { canonical: "/telif" },
};

export default function CopyrightPage() {
  return (
    <LegalPage title="Telif ve Marka Bildirimi" updated="Taslak">
      <h2>Marka bildirimi</h2>
      <p>eFootball ve Konami adları ile ilgili logolar ve oyun içi görseller, ilgili hak sahiplerinin (Konami Digital Entertainment) markaları ve eserleridir. Bu site onlarla bağlantılı değildir, onlar tarafından onaylanmamıştır veya desteklenmemiştir.</p>

      <h2>Kullanıcı içeriği</h2>
      <p>Yüklediğiniz görseller ve yazdığınız metinler için gerekli haklara sahip olduğunuzu ve üçüncü kişilerin haklarını ihlal etmediğinizi beyan edersiniz.</p>

      <h2>İhlal bildirimi</h2>
      <p>Haklarınızın ihlal edildiğini düşünüyorsanız, ilgili içeriğin bağlantısını ve hak sahipliğinizi gösteren bilgiyi sitedeki iletişim kanalları üzerinden iletin. İnceleme sonrasında içerik kaldırılabilir.</p>
    </LegalPage>
  );
}
