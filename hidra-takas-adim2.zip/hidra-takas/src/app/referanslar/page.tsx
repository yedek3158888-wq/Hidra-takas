import type { Metadata } from "next";
import { getApprovedReferences } from "@/lib/data";
import { ReferenceCard } from "@/components/ReferenceCard";
import { EmptyState, SetupNotice } from "@/components/EmptyState";
import { Icon } from "@/components/Icons";

export const revalidate = 60;

export const metadata: Metadata = {
  title: "Referanslar",
  description: "Yönetici tarafından incelenen takas referansları.",
  alternates: { canonical: "/referanslar" },
};

export default async function ReferencesPage() {
  const res = await getApprovedReferences(60);

  return (
    <div className="wrap py-10 sm:py-14">
      <h1 className="text-3xl font-extrabold tracking-tight">Referanslar</h1>
      <div className="card mt-4 flex gap-3 p-4 text-sm leading-relaxed text-muted">
        <Icon name="alert" className="mt-0.5 h-5 w-5 shrink-0 text-amber-300" />
        <p>
          Referanslar yayınlanmadan önce yönetici tarafından incelenir. Her referansın kaynağı etiketlenir:
          <strong className="text-ink"> “Kullanıcı beyanı”</strong> kullanıcının kendi paylaşımıdır ve bağımsız olarak
          doğrulanmış değildir. Hiçbir referans, bir işlemin güvenli olduğunun garantisi değildir.
        </p>
      </div>

      <div className="mt-8 space-y-6">
        {res.unavailable ? <SetupNotice /> : null}
        {res.data.length > 0 ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {res.data.map((r) => <ReferenceCard key={r.id} reference={r} />)}
          </div>
        ) : !res.unavailable ? (
          <EmptyState icon="shield" title="Henüz onaylanmış referans yok">
            Onaylanan referanslar burada herkese açık olarak gösterilir. Henüz yayınlanmış bir referans bulunmuyor.
          </EmptyState>
        ) : null}
      </div>
    </div>
  );
}
