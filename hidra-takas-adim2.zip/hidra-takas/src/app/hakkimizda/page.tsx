import type { Metadata } from "next";
import { getSettings } from "@/lib/settings";

export const metadata: Metadata = {
  title: "Hakkımızda",
  description: "Platformun ne olduğu ve ne olmadığı.",
  alternates: { canonical: "/hakkimizda" },
};

export default async function AboutPage() {
  const s = await getSettings();
  return (
    <div className="wrap max-w-3xl py-10 sm:py-14">
      <h1 className="text-3xl font-extrabold tracking-tight">Hakkımızda</h1>
      <div className="mt-6 space-y-5 text-[15px] leading-7 text-ink/90">
        <p>
          {s.brand_name}, eFootball hesap takası yapmak isteyen oyuncular için hazırlanmış bağımsız bir topluluk ilan
          panosudur. Amaç; ilanları tek yerde göstermek, kullanıcıların yorum yapabilmesini ve paylaşılan referansların
          incelenmesini sağlamak ve taraflar arasında doğrudan iletişimi kolaylaştırmaktır.
        </p>
        <h2 className="pt-2 text-xl font-bold">Ne yapmıyoruz?</h2>
        <ul className="list-disc space-y-2 pl-5">
          <li>Konami veya eFootball ile hiçbir resmî bağımız yoktur.</li>
          <li>Ödeme, emanet veya hesap devri aracılığı yapmayız.</li>
          <li>İlanlardaki hesapların gerçekliğini veya devredilebilirliğini garanti etmeyiz.</li>
          <li>Hiçbir zaman şifre, kurtarma kodu veya doğrulama kodu istemeyiz.</li>
        </ul>
        <h2 className="pt-2 text-xl font-bold">Şeffaflık</h2>
        <p>
          Sitedeki sayılar veritabanındaki gerçek kayıtlardan hesaplanır. Referanslar yayınlanmadan önce incelenir ve
          kaynakları (kullanıcı beyanı veya yönetici incelemesi) etiketlenir.
        </p>
      </div>
    </div>
  );
}
