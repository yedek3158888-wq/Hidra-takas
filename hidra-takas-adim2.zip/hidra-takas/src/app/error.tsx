"use client";

// Hata ayrıntıları (sorgu, anahtar vb.) kullanıcıya gösterilmez.
export default function GlobalError({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <div className="wrap grid min-h-[60dvh] place-items-center py-16 text-center">
      <div>
        <p className="text-5xl font-extrabold text-amber-300">!</p>
        <h1 className="mt-3 text-2xl font-bold">Bir şeyler ters gitti</h1>
        <p className="mx-auto mt-2 max-w-sm text-sm text-muted">
          Sayfa yüklenirken beklenmedik bir hata oluştu. Lütfen tekrar deneyin.
        </p>
        <button type="button" onClick={() => reset()} className="btn-primary mt-6">
          Tekrar dene
        </button>
      </div>
    </div>
  );
}
