import type { Metadata } from "next";
import { getChannels, getSettings } from "@/lib/settings";
import { ChannelButton } from "@/components/ChannelButton";
import { Icon } from "@/components/Icons";

export const revalidate = 60;

export const metadata: Metadata = {
  title: "İletişim",
  description: "Telegram, Instagram ve Threads üzerinden iletişim.",
  alternates: { canonical: "/iletisim" },
};

export default async function ContactPage() {
  const s = await getSettings();
  const c = getChannels(s);

  return (
    <div className="wrap max-w-3xl py-10 sm:py-14">
      <h1 className="text-3xl font-extrabold tracking-tight">İletişim</h1>
      <p className="mt-3 text-[15px] leading-7 text-muted">{s.contact_text}</p>

      <div className="mt-8 grid gap-3 sm:grid-cols-3">
        <ChannelButton channel="telegram" label="Telegram" info={c.telegram} variant="primary" prefix="Telegram" />
        <ChannelButton channel="instagram" label="Instagram" info={c.instagram} prefix="Instagram" />
        <ChannelButton channel="threads" label="Threads" info={c.threads} prefix="Threads" />
      </div>

      <div className="card mt-8 flex gap-3 p-4 text-sm leading-relaxed text-muted">
        <Icon name="alert" className="mt-0.5 h-5 w-5 shrink-0 text-amber-300" />
        <p>
          Bu sitede mesajlaşma sistemi yoktur; yukarıdaki düğmeler sizi ilgili harici platforma yönlendirir.
          Şifre, kurtarma kodu veya doğrulama kodu paylaşmayın; bunları isteyen herkesi dikkatle değerlendirin.
        </p>
      </div>
    </div>
  );
}
