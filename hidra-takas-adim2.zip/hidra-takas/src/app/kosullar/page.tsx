import type { Metadata } from "next";
import { LegalPage } from "@/components/LegalPage";

export const metadata: Metadata = {
  title: "Kullanım Koşulları",
  alternates: { canonical: "/kosullar" },
};

export default function TermsPage() {
  return (
    <LegalPage title="Kullanım Koşulları" updated="Taslak">
      <h2>Hizmetin niteliği</h2>
      <p>Site, kullanıcıların hesap ilanlarını görebildiği bağımsız bir ilan panosudur. Ödeme, emanet, hesap devri veya takas aracılığı hizmeti sunmaz. İşlemler yalnızca taraflar arasındadır.</p>

      <h2>Oyun sağlayıcısı koşulları ve risk</h2>
      <p>Hesap takası, paylaşımı veya satışı oyun sağlayıcısının kullanım koşullarına aykırı olabilir ve hesabın askıya alınması ya da kalıcı olarak kaybedilmesiyle sonuçlanabilir. Bu riski kabul ederek hareket edersiniz.</p>

      <h2>Garanti verilmez</h2>
      <p>İlan bilgileri ilan sahibinin beyanıdır. Site, hesapların gerçekliğini, devredilebilirliğini veya bir işlemin sonucunu garanti etmez. Referanslar ve yorumlar kullanıcı içeriğidir; kesin güvence oluşturmaz.</p>

      <h2>Kullanıcı davranışı</h2>
      <ul>
        <li>Şifre, kurtarma kodu, doğrulama kodu veya ödeme bilgisi paylaşmayın.</li>
        <li>Başkalarının kişisel bilgilerini ve yüzlerini izinsiz paylaşmayın.</li>
        <li>Sahte, yanıltıcı, hakaret içeren veya spam içerik yayınlamayın.</li>
      </ul>

      <h2>Moderasyon</h2>
      <p>Yöneticiler, bu koşullara aykırı içeriği önceden haber vermeden gizleyebilir veya kaldırabilir ve ihlal eden hesapları kısıtlayabilir.</p>

      <h2>Sorumluluğun sınırı</h2>
      <p>Yürürlükteki mevzuatın izin verdiği ölçüde, sitenin işletmecisi kullanıcılar arasındaki işlemlerden doğan zararlardan sorumlu tutulamaz.</p>
    </LegalPage>
  );
}
