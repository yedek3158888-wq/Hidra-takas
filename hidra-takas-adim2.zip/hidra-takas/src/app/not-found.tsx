import Link from "next/link";

export default function NotFound() {
  return (
    <div className="wrap grid min-h-[60dvh] place-items-center py-16 text-center">
      <div>
        <p className="text-6xl font-extrabold text-brand">404</p>
        <h1 className="mt-3 text-2xl font-bold">Sayfa bulunamadı</h1>
        <p className="mx-auto mt-2 max-w-sm text-sm text-muted">
          Aradığınız sayfa taşınmış, kaldırılmış veya hiç var olmamış olabilir.
        </p>
        <div className="mt-6 flex justify-center gap-3">
          <Link href="/" className="btn-primary">Ana sayfa</Link>
          <Link href="/hesaplar" className="btn-ghost">Hesaplar</Link>
        </div>
      </div>
    </div>
  );
}
