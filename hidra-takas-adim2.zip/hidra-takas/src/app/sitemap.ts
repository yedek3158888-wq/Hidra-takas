import type { MetadataRoute } from "next";
import { getSiteUrl } from "@/lib/site";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = getSiteUrl();
  const paths = ["", "/hesaplar", "/referanslar", "/hakkimizda", "/iletisim", "/gizlilik", "/kosullar", "/telif"];
  return paths.map((p) => ({
    url: `${base}${p}`,
    changeFrequency: (p === "" || p === "/hesaplar" ? "daily" : "monthly") as "daily" | "monthly",
    priority: p === "" ? 1 : p === "/hesaplar" ? 0.9 : 0.5,
  }));
}
