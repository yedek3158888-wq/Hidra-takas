import Link from "next/link";
import { getSettings, getChannels } from "@/lib/settings";
import { getApprovedReferences, getFeaturedListings, getLatestListings, getPublicStats } from "@/lib/data";
import { ListingCard } from "@/components/ListingCard";
import { ReferenceCard } from "@/components/ReferenceCard";
import { ChannelButton } from "@/components/ChannelButton";
import { EmptyState, SetupNotice } from "@/components/EmptyState";
import { Icon } from "@/components/Icons";
import { formatNumber } from "@/lib/format";

export const revalidate = 60;

const STEPS = [
  { t: "İlanı incele", d: "Hesaplar sayfasındaki ilanlara göz atın; takım gücü, oyuncular ve takas koşullarını okuyun." },
  { t: "Yorumlara ve referanslara bak", d: "Diğer kullanıcıların yorumlarını ve paylaşılan referansları inceleyin. Referansların kaynağı etiketlenir." },
  { t: "Doğrudan iletişime geç", d: "İlan sahibiyle Telegram veya Instagram üzerinden yazışın. Site mesajlaşma ya da aracılık hizmeti sunmaz." },
  { t: "Riski kendin değerlendir", d: "Takas tamamen taraflar arasındadır. Şifre, kurtarma ve doğrulama kodlarını kimseyle paylaşma kararının sorumluluğu size aittir." },
];

export default async function HomePage() {
  const s = await getSettings();
  const channels = getChannels(s);
  const [featured, latest, refs, stats] = await Promise.all([
    getFeaturedListings(3),
    getLatestListings(6),
    getApprovedReferences(4),
    getPublicStats(),
  ]);
  const dbDown = featured.unavailable || latest.unavailable || stats.unavailable;

  return (
    <>
      {/* HERO */}
      <section className="hero-bg border-b border-line">
        <div className="wrap grid gap-10 py-14 sm:py-20 lg:grid-cols-[1.2fr_0.8fr] lg:items-center">
          <div className="animate-rise">
            <p className="chip mb-5 gap-2 !border-brand/40 !text-sky-200">
              <span className="h-1.5 w-1.5 rounded-full bg-accent" /> eFootball hesap takası topluluğu
            </p>
            <h1 className="text-4xl font-extrabold leading-[1.1] tracking-tight sm:text-5xl lg:text-6xl">
              {s.slogan}
            </h1>
            <p className="mt-5 max-w-xl text-base leading-relaxed text-muted sm:text-lg">{s.description}</p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Link href="/hesaplar" className="btn-primary">
                Hesapları İncele
                <Icon name="grid" className="h-4 w-4" />
              </Link>
              <ChannelButton channel="telegram" label="Telegram" info={channels.telegram} prefix="Telegram'dan İletişim" />
            </div>
            <p className="mt-4 text-xs text-muted">
              Telegram bağlantısı harici bir platformu açar. Site, Konami veya eFootball ile bağlantılı değildir.
            </p>
          </div>

          {/* İstatistikler: yalnızca veritabanından gelen gerçek sayılar */}
          {stats.data ? (
            <dl className="card grid grid-cols-2 gap-px overflow-hidden bg-line animate-rise">
              {[
                { l: "Aktif ilan", v: stats.data.active_listings },
                { l: "Takas tamamlandı (işaretli ilan)", v: stats.data.completed_listings },
                { l: "Onaylı referans", v: stats.data.approved_references },
                { l: "Yayındaki yorum", v: stats.data.visible_comments },
              ].map((x) => (
                <div key={x.l} className="bg-card p-5">
                  <dd className="text-3xl font-extrabold text-brand">{formatNumber(x.v)}</dd>
                  <dt className="mt-1 text-xs leading-snug text-muted">{x.l}</dt>
                </div>
              ))}
              <p className="col-span-2 bg-card px-5 py-3 text-[11px] text-muted">
                Sayılar veritabanından canlı hesaplanır. “Takas tamamlandı”, yönetici tarafından işaretlenen ilanları
                gösterir.
              </p>
            </dl>
          ) : null}
        </div>
      </section>

      <div className="wrap space-y-16 pt-12 sm:space-y-20 sm:pt-16">
        {dbDown ? <SetupNotice /> : null}

        {/* ÖNE ÇIKAN */}
        {s.sections.featured ? (
          <section aria-labelledby="oneCikan">
            <div className="mb-5 flex items-end justify-between">
              <h2 id="oneCikan" className="section-title">Öne çıkan ilanlar</h2>
              <Link href="/hesaplar" className="text-sm font-medium text-brand hover:underline">Tümü →</Link>
            </div>
            {featured.data.length > 0 ? (
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {featured.data.map((l) => <ListingCard key={l.id} listing={l} />)}
              </div>
            ) : (
              <EmptyState icon="bolt" title="Henüz öne çıkan ilan yok">
                Yönetici bir ilanı öne çıkardığında burada görünecek.
              </EmptyState>
            )}
          </section>
        ) : null}

        {/* SON EKLENEN */}
        {s.sections.latest ? (
          <section aria-labelledby="sonEklenen">
            <div className="mb-5 flex items-end justify-between">
              <h2 id="sonEklenen" className="section-title">Son eklenen ilanlar</h2>
              <Link href="/hesaplar" className="text-sm font-medium text-brand hover:underline">Tümü →</Link>
            </div>
            {latest.data.length > 0 ? (
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {latest.data.map((l) => <ListingCard key={l.id} listing={l} />)}
              </div>
            ) : (
              <EmptyState icon="grid" title="Henüz ilan yok">
                İlanlar yayınlandığında burada listelenecek. Takas veya satış duyurusu için bizimle iletişime geçebilirsiniz.
              </EmptyState>
            )}
          </section>
        ) : null}

        {/* REFERANSLAR */}
        {s.sections.references ? (
          <section aria-labelledby="refler">
            <div className="mb-5 flex items-end justify-between">
              <h2 id="refler" className="section-title">Son onaylanan referanslar</h2>
              <Link href="/referanslar" className="text-sm font-medium text-brand hover:underline">Tümü →</Link>
            </div>
            {refs.data.length > 0 ? (
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                {refs.data.map((r) => <ReferenceCard key={r.id} reference={r} />)}
              </div>
            ) : (
              <EmptyState icon="shield" title="Henüz onaylanmış referans yok">
                Yöneticiler tarafından incelenip onaylanan referanslar burada gösterilir. Henüz yayınlanmış bir
                referans bulunmuyor.
              </EmptyState>
            )}
          </section>
        ) : null}

        {/* NASIL İŞLER */}
        {s.sections.steps ? (
          <section aria-labelledby="nasil">
            <h2 id="nasil" className="section-title mb-5">Nasıl işliyor?</h2>
            <ol className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {STEPS.map((st, i) => (
                <li key={st.t} className="card p-5">
                  <span className="mb-3 grid h-9 w-9 place-items-center rounded-xl bg-brand/15 text-sm font-bold text-brand">
                    {i + 1}
                  </span>
                  <h3 className="font-semibold">{st.t}</h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-muted">{st.d}</p>
                </li>
              ))}
            </ol>
          </section>
        ) : null}

        {/* GÜVENLİK VE RİSK */}
        {s.sections.risk ? (
          <section aria-labelledby="risk" className="card border-amber-500/40 bg-amber-500/5 p-5 sm:p-7">
            <div className="flex items-start gap-3">
              <Icon name="alert" className="mt-1 h-6 w-6 shrink-0 text-amber-300" />
              <div>
                <h2 id="risk" className="text-lg font-bold text-amber-100">Güvenlik ve risk bilgilendirmesi</h2>
                <ul className="mt-3 space-y-2 text-sm leading-relaxed text-amber-50/90">
                  <li>Hesap takası veya paylaşımı oyun sağlayıcısının koşullarıyla çelişebilir ve hesabınızın kalıcı olarak kaybına yol açabilir.</li>
                  <li>Site ilanların gerçekliğini veya hesapların devredilebilirliğini garanti etmez; bilgiler ilan sahibinin beyanıdır.</li>
                  <li>Site hiçbir zaman şifre, kurtarma kodu veya doğrulama kodu istemez. Böyle bir talebi bildirin.</li>
                  <li>Site ödeme, emanet veya hesap devri aracılığı yapmaz. Tüm işlemler taraflar arasındadır.</li>
                </ul>
              </div>
            </div>
          </section>
        ) : null}

        {/* SSS */}
        {s.sections.faq ? (
          <section aria-labelledby="sss">
            <h2 id="sss" className="section-title mb-5">Sık sorulan sorular</h2>
            <div className="space-y-3">
              {s.faq.map((f) => (
                <details key={f.q} className="card group px-5">
                  <summary className="flex min-h-[56px] cursor-pointer items-center justify-between gap-4 text-[15px] font-semibold">
                    {f.q}
                    <Icon name="chevron" className="faq-chevron h-5 w-5 shrink-0 text-muted transition" />
                  </summary>
                  <p className="pb-4 text-sm leading-relaxed text-muted">{f.a}</p>
                </details>
              ))}
            </div>
          </section>
        ) : null}
      </div>
    </>
  );
}
