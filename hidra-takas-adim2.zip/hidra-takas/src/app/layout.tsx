import type { Metadata, Viewport } from "next";
import type { CSSProperties, ReactNode } from "react";
import "./globals.css";
import { getSettings, getChannels, hexToTriplet } from "@/lib/settings";
import { getSiteUrl } from "@/lib/site";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { BottomNav } from "@/components/BottomNav";

export async function generateMetadata(): Promise<Metadata> {
  const s = await getSettings();
  const title = `${s.brand_name} | eFootball Hesap Takası Topluluğu`;
  return {
    metadataBase: new URL(getSiteUrl()),
    title: { default: title, template: `%s | ${s.brand_name}` },
    description: s.description,
    applicationName: s.brand_name,
    alternates: { canonical: "/" },
    icons: { icon: s.favicon_url || "/icon.svg" },
    openGraph: {
      type: "website",
      locale: "tr_TR",
      siteName: s.brand_name,
      title,
      description: s.description,
    },
    twitter: { card: "summary", title, description: s.description },
    robots: { index: true, follow: true },
  };
}

export const viewport: Viewport = {
  themeColor: "#07090d",
  width: "device-width",
  initialScale: 1,
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  const s = await getSettings();
  const channels = getChannels(s);
  const vars = {
    "--brand": hexToTriplet(s.colors.brand),
    "--accent": hexToTriplet(s.colors.accent),
  } as CSSProperties;

  return (
    <html lang="tr" style={vars}>
      <body>
        <a
          href="#icerik"
          className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-50 focus:rounded-lg focus:bg-brand focus:px-4 focus:py-2 focus:text-white"
        >
          İçeriğe geç
        </a>
        <Header brandName={s.brand_name} logoUrl={s.logo_url} telegram={channels.telegram} />
        <main id="icerik">{children}</main>
        <Footer brandName={s.brand_name} logoUrl={s.logo_url} footerText={s.footer_text} channels={channels} />
        <BottomNav />
      </body>
    </html>
  );
}
