import type { Metadata } from "next";
import Link from "next/link";
import { searchListings } from "@/lib/data";
import { getChannels, getSettings } from "@/lib/settings";
import { ListingCard } from "@/components/ListingCard";
import { EmptyState, SetupNotice } from "@/components/EmptyState";
import { ChannelButton } from "@/components/ChannelButton";
import { Icon } from "@/components/Icons";

export const metadata: Metadata = {
  title: "Hesaplar",
  description: "Güncel eFootball hesap ilanları.",
  alternates: { canonical: "/hesaplar" },
};

const PAGE_SIZE = 12;

function pageHref(q: string, page: number): string {
  const p = new URLSearchParams();
  if (q) p.set("q", q);
  if (page > 1) p.set("sayfa", String(page));
  const qs = p.toString();
  return qs ? `/hesaplar?${qs}` : "/hesaplar";
}

export default async function ListingsPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; sayfa?: string }>;
}) {
  const sp = await searchParams;
  const q = (sp.q ?? "").trim().slice(0, 80);
  const page = Math.max(1, Math.min(1000, parseInt(sp.sayfa ?? "1", 10) || 1));

  const [res, settings] = await Promise.all([searchListings({ q, page, pageSize: PAGE_SIZE }), getSettings()]);
  const channels = getChannels(settings);
  const { items, total } = res.data;
  const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  return (
    <div className="wrap py-10 sm:py-14">
      <h1 className="text-3xl font-extrabold tracking-tight">Hesaplar</h1>
      <p className="mt-2 text-sm text-muted">
        İlan bilgileri ilan sahibinin beyanıdır; site hesapların gerçekliğini veya devredilebilirliğini garanti etmez.
      </p>

      <form action="/hesaplar" method="get" role="search" className="mt-6 flex gap-2">
        <label htmlFor="q" className="sr-only">İlan başlığında ara</label>
        <div className="relative flex-1">
          <Icon name="search" className="pointer-events-none absolute left-3.5 top-1/2 h-[18px] w-[18px] -translate-y-1/2 text-muted" />
          <input
            id="q"
            name="q"
            defaultValue={q}
            maxLength={80}
            placeholder="İlan başlığında ara…"
            className="min-h-[46px] w-full rounded-xl border border-line bg-surface pl-10 pr-3 text-sm placeholder:text-muted focus:border-brand"
          />
        </div>
        <button type="submit" className="btn-primary">Ara</button>
      </form>

      <div className="mt-8 space-y-6">
        {res.unavailable ? <SetupNotice /> : null}

        {items.length > 0 ? (
          <>
            <p className="text-sm text-muted">{total} ilan{q ? ` (“${q}” için)` : ""}</p>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {items.map((l) => <ListingCard key={l.id} listing={l} />)}
            </div>
            {pages > 1 ? (
              <nav aria-label="Sayfalama" className="flex items-center justify-between pt-2">
                {page > 1 ? (
                  <Link href={pageHref(q, page - 1)} className="btn-ghost">← Önceki</Link>
                ) : <span />}
                <span className="text-sm text-muted">Sayfa {page} / {pages}</span>
                {page < pages ? (
                  <Link href={pageHref(q, page + 1)} className="btn-ghost">Sonraki →</Link>
                ) : <span />}
              </nav>
            ) : null}
          </>
        ) : !res.unavailable ? (
          <EmptyState
            icon="search"
            title={q ? "Aramanızla eşleşen ilan bulunamadı" : "Henüz yayında ilan yok"}
            action={
              q ? (
                <Link href="/hesaplar" className="btn-ghost">Aramayı temizle</Link>
              ) : (
                <ChannelButton channel="telegram" label="Telegram" info={channels.telegram} prefix="Telegram'dan sor" />
              )
            }
          >
            {q ? "Farklı bir kelimeyle tekrar deneyin." : "Yeni ilanlar eklendiğinde burada listelenecek."}
          </EmptyState>
        ) : null}
      </div>
    </div>
  );
}
