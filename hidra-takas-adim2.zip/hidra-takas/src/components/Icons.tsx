import type { ReactNode, SVGProps } from "react";

export type IconName =
  | "home"
  | "grid"
  | "shield"
  | "chat"
  | "telegram"
  | "instagram"
  | "threads"
  | "external"
  | "chevron"
  | "search"
  | "check"
  | "alert"
  | "bolt"
  | "image";

const PATHS: Record<IconName, ReactNode> = {
  home: <path d="M3 11.5 12 4l9 7.5M5.5 10v9.5h13V10" />,
  grid: (
    <>
      <rect x="3.5" y="3.5" width="7" height="7" rx="1.5" />
      <rect x="13.5" y="3.5" width="7" height="7" rx="1.5" />
      <rect x="3.5" y="13.5" width="7" height="7" rx="1.5" />
      <rect x="13.5" y="13.5" width="7" height="7" rx="1.5" />
    </>
  ),
  shield: <path d="M12 3 4.5 6v5.5c0 4.5 3.2 8 7.5 9.5 4.3-1.5 7.5-5 7.5-9.5V6L12 3Zm-3 9 2.2 2.2L15.5 10" />,
  chat: <path d="M4 5.5h16v10H9.5L5 19.5v-4H4v-10Z" />,
  telegram: <path d="m21 4-3 15-5.5-4-3 3v-4.5L18 7 7 12.5 3 11l18-7Z" />,
  instagram: (
    <>
      <rect x="3.5" y="3.5" width="17" height="17" rx="5" />
      <circle cx="12" cy="12" r="3.8" />
      <circle cx="17" cy="7" r="0.8" fill="currentColor" />
    </>
  ),
  threads: <path d="M16.5 9.5c-.4-2.6-2.2-4-4.7-4-3 0-5 2.2-5 6.5s2 6.5 5 6.5c2.6 0 4.5-1.4 4.5-3.5 0-2-1.8-3-4.3-3-1.3 0-2.2.5-2.2 1.5s.9 1.5 1.9 1.5c1.9 0 3.1-1.4 3.1-4.5" />,
  external: <path d="M14 4h6v6M20 4l-9 9M18 14v5.5H4.5V6H10" />,
  chevron: <path d="m6 9 6 6 6-6" />,
  search: (
    <>
      <circle cx="11" cy="11" r="6.5" />
      <path d="m16 16 4.5 4.5" />
    </>
  ),
  check: <path d="m5 12.5 4.5 4.5L19 7.5" />,
  alert: <path d="M12 4 2.8 19.5h18.4L12 4Zm0 5.5v5m0 2.5v.1" />,
  bolt: <path d="M13 3 5 13.5h6L10 21l8-10.5h-6L13 3Z" />,
  image: (
    <>
      <rect x="3.5" y="4.5" width="17" height="15" rx="2.5" />
      <circle cx="9" cy="10" r="1.6" />
      <path d="m4 17 5-4.5 3.5 3L16 12l4.5 4" />
    </>
  ),
};

export function Icon({ name, className = "h-5 w-5", ...rest }: { name: IconName } & SVGProps<SVGSVGElement>) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      className={className}
      {...rest}
    >
      {PATHS[name]}
    </svg>
  );
}
