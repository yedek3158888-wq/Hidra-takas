import Link from "next/link";
import type { ChannelInfo } from "@/lib/contact";
import { Logo } from "./Logo";
import { Icon } from "./Icons";

export function Footer({
  brandName,
  logoUrl,
  footerText,
  channels,
}: {
  brandName: string;
  logoUrl: string;
  footerText: string;
  channels: { telegram: ChannelInfo | null; instagram: ChannelInfo | null; threads: ChannelInfo | null };
}) {
  const social = [
    { key: "telegram", info: channels.telegram, label: "Telegram" },
    { key: "instagram", info: channels.instagram, label: "Instagram" },
    { key: "threads", info: channels.threads, label: "Threads" },
  ] as const;

  return (
    <footer className="mt-20 border-t border-line bg-surface/60">
      <div className="wrap grid gap-10 py-12 md:grid-cols-[1.4fr_1fr_1fr]">
        <div className="space-y-4">
          <Logo name={brandName} logoUrl={logoUrl || undefined} />
          <p className="max-w-sm text-sm leading-relaxed text-muted">
            {footerText || "Bağımsız bir topluluk ilan panosudur. Ödeme, hesap devri veya emanet hizmeti sunmaz."}
          </p>
          <ul className="flex flex-wrap gap-2">
            {social.map(({ key, info, label }) =>
              info ? (
                <li key={key}>
                  <a
                    href={info.url}
                    target="_blank"
                    rel="noopener noreferrer nofollow"
                    className="btn-ghost !min-h-[40px] !px-3"
                    title={`${label} (${info.host}) adresine yönlendirilirsiniz`}
                  >
                    <Icon name={key} className="h-4 w-4" />
                    {label}
                    <span className="sr-only">Harici site: {info.host}</span>
                  </a>
                </li>
              ) : null,
            )}
          </ul>
        </div>

        <nav aria-label="Site bağlantıları">
          <h2 className="mb-3 text-sm font-semibold">Site</h2>
          <ul className="space-y-2 text-sm text-muted">
            <li><Link className="hover:text-ink" href="/hesaplar">Hesaplar</Link></li>
            <li><Link className="hover:text-ink" href="/referanslar">Referanslar</Link></li>
            <li><Link className="hover:text-ink" href="/hakkimizda">Hakkımızda</Link></li>
            <li><Link className="hover:text-ink" href="/iletisim">İletişim</Link></li>
          </ul>
        </nav>

        <nav aria-label="Yasal">
          <h2 className="mb-3 text-sm font-semibold">Yasal</h2>
          <ul className="space-y-2 text-sm text-muted">
            <li><Link className="hover:text-ink" href="/gizlilik">Gizlilik ve Çerezler</Link></li>
            <li><Link className="hover:text-ink" href="/kosullar">Kullanım Koşulları</Link></li>
            <li><Link className="hover:text-ink" href="/telif">Telif ve Marka Bildirimi</Link></li>
          </ul>
        </nav>
      </div>

      <div className="border-t border-line">
        <p className="wrap py-5 pb-24 text-xs leading-relaxed text-muted md:pb-5">
          © {new Date().getFullYear()} {brandName}. Bu site Konami Digital Entertainment veya eFootball&apos;un resmî
          bir hizmeti değildir ve onlarla bağlantılı değildir. eFootball ve Konami ilgili hak sahiplerinin
          markalarıdır.
        </p>
      </div>
    </footer>
  );
}
