"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Icon, type IconName } from "./Icons";

const ITEMS: { href: string; label: string; icon: IconName }[] = [
  { href: "/", label: "Ana Sayfa", icon: "home" },
  { href: "/hesaplar", label: "Hesaplar", icon: "grid" },
  { href: "/referanslar", label: "Referanslar", icon: "shield" },
  { href: "/iletisim", label: "İletişim", icon: "chat" },
];

export function BottomNav() {
  const pathname = usePathname();
  return (
    <nav
      aria-label="Alt menü"
      className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-surface/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-xl md:hidden"
    >
      <ul className="mx-auto grid max-w-md grid-cols-4">
        {ITEMS.map((item) => {
          const active = item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
          return (
            <li key={item.href}>
              <Link
                href={item.href}
                aria-current={active ? "page" : undefined}
                className={`flex min-h-[56px] flex-col items-center justify-center gap-0.5 text-[11px] font-medium transition ${
                  active ? "text-brand" : "text-muted active:text-ink"
                }`}
              >
                <span
                  className={`grid h-7 w-12 place-items-center rounded-full transition ${active ? "bg-brand/15" : ""}`}
                >
                  <Icon name={item.icon} className="h-5 w-5" />
                </span>
                {item.label}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
