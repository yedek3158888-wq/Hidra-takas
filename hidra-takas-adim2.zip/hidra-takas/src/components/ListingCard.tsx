import Link from "next/link";
import type { Listing, ListingStatus } from "@/lib/types";
import { STATUS_LABEL, formatDate, formatNumber, formatPrice, listingNo } from "@/lib/format";
import { publicStorageUrl } from "@/lib/supabase";
import { Icon } from "./Icons";

const STATUS_STYLE: Record<ListingStatus, string> = {
  aktif: "bg-emerald-400/10 text-emerald-300 border-emerald-400/30",
  beklemede: "bg-amber-400/10 text-amber-300 border-amber-400/30",
  takas_tamamlandi: "bg-brand/15 text-sky-200 border-brand/40",
  yayindan_kaldirildi: "bg-red-400/10 text-red-300 border-red-400/30",
};

export function StatusBadge({ status }: { status: ListingStatus }) {
  return (
    <span className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium ${STATUS_STYLE[status]}`}>
      {STATUS_LABEL[status]}
    </span>
  );
}

export function ListingCard({ listing }: { listing: Listing }) {
  const cover = listing.listing_images[0];
  const price = formatPrice(listing.price, listing.currency);

  return (
    <Link
      href={`/hesaplar/${listing.listing_no}`}
      className="card group flex flex-col overflow-hidden transition duration-300 hover:-translate-y-1 hover:border-brand/50"
    >
      <div className="relative aspect-[16/10] overflow-hidden bg-surface">
        {cover ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={publicStorageUrl("listing-images", cover.path)}
            alt={cover.alt || listing.title}
            loading="lazy"
            decoding="async"
            className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
          />
        ) : (
          <div className="grid h-full w-full place-items-center text-muted">
            <Icon name="image" className="h-10 w-10 opacity-50" />
          </div>
        )}
        <div className="absolute left-3 top-3 flex gap-2">
          <StatusBadge status={listing.status} />
          {listing.is_featured ? (
            <span className="inline-flex items-center rounded-full border border-accent/40 bg-bg/70 px-2.5 py-0.5 text-xs font-medium text-accent backdrop-blur">
              Öne çıkan
            </span>
          ) : null}
        </div>
      </div>

      <div className="flex flex-1 flex-col gap-3 p-4">
        <div className="flex items-center justify-between text-xs text-muted">
          <span className="font-mono">{listingNo(listing.listing_no)}</span>
          <span>{formatDate(listing.created_at)}</span>
        </div>
        <h3 className="line-clamp-2 text-base font-semibold leading-snug">{listing.title}</h3>

        <dl className="mt-auto grid grid-cols-2 gap-2 text-sm">
          <div>
            <dt className="text-xs text-muted">Platform</dt>
            <dd className="truncate font-medium">{listing.platform}</dd>
          </div>
          <div>
            <dt className="text-xs text-muted">Takım gücü</dt>
            <dd className="font-medium">{listing.team_strength != null ? formatNumber(listing.team_strength) : "—"}</dd>
          </div>
        </dl>

        {listing.tags.length > 0 ? (
          <ul className="flex flex-wrap gap-1.5">
            {listing.tags.slice(0, 4).map((t) => (
              <li key={t} className="chip">{t}</li>
            ))}
          </ul>
        ) : null}

        {price ? <p className="text-sm font-semibold text-accent">{price}</p> : null}
      </div>
    </Link>
  );
}
