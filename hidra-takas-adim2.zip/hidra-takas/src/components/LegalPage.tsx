import type { ReactNode } from "react";
import { Icon } from "./Icons";

export function LegalPage({ title, updated, children }: { title: string; updated: string; children: ReactNode }) {
  return (
    <div className="wrap max-w-3xl py-10 sm:py-14">
      <div role="note" className="card mb-8 flex gap-3 border-amber-500/40 bg-amber-500/5 p-4 text-sm text-amber-100">
        <Icon name="alert" className="mt-0.5 h-5 w-5 shrink-0" />
        <p>
          <strong>TASLAK METİN.</strong> Bu sayfa hukuki danışmanlık değildir ve yayınlanmadan önce bir avukat
          tarafından kontrol edilmelidir. Yürürlükteki mevzuata (ör. KVKK) uygunluğu garanti edilmez.
        </p>
      </div>
      <h1 className="text-3xl font-extrabold tracking-tight">{title}</h1>
      <p className="mt-2 text-sm text-muted">Son güncelleme: {updated}</p>
      <div className="mt-8 space-y-6 text-[15px] leading-7 text-ink/90 [&_h2]:mt-10 [&_h2]:text-xl [&_h2]:font-bold [&_h2]:text-ink [&_li]:ml-5 [&_li]:list-disc [&_li]:pl-1 [&_ul]:space-y-1.5">
        {children}
      </div>
    </div>
  );
}
