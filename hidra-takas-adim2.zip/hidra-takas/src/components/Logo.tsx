import Link from "next/link";
import { Icon } from "./Icons";

export function Logo({ name, logoUrl }: { name: string; logoUrl?: string }) {
  return (
    <Link href="/" className="flex items-center gap-2.5" aria-label={`${name} ana sayfa`}>
      {logoUrl ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={logoUrl} alt="" className="h-8 w-8 rounded-lg object-cover" width={32} height={32} />
      ) : (
        <span className="grid h-8 w-8 place-items-center rounded-lg bg-brand text-white shadow-glow">
          <Icon name="bolt" className="h-[18px] w-[18px]" />
        </span>
      )}
      <span className="text-[15px] font-extrabold tracking-wide sm:text-base">{name}</span>
    </Link>
  );
}
