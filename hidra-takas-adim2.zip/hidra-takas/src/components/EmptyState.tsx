import type { ReactNode } from "react";
import { Icon, type IconName } from "./Icons";

export function EmptyState({
  icon = "image",
  title,
  children,
  action,
}: {
  icon?: IconName;
  title: string;
  children?: ReactNode;
  action?: ReactNode;
}) {
  return (
    <div className="card flex flex-col items-center gap-3 border-dashed px-6 py-12 text-center">
      <span className="grid h-12 w-12 place-items-center rounded-2xl bg-brand/10 text-brand">
        <Icon name={icon} className="h-6 w-6" />
      </span>
      <h3 className="text-base font-semibold">{title}</h3>
      {children ? <p className="max-w-md text-sm leading-relaxed text-muted">{children}</p> : null}
      {action ? <div className="mt-2">{action}</div> : null}
    </div>
  );
}

/** Veritabanı bağlı değilken veya sorgu hata verdiğinde gösterilir. */
export function SetupNotice() {
  return (
    <div role="status" className="card border-amber-500/40 bg-amber-500/5 p-4 text-sm leading-relaxed text-amber-100">
      <strong className="font-semibold">Veritabanı bağlantısı kurulamadı.</strong> Site yönetici tarafından henüz
      yapılandırılmamış olabilir. Yöneticiyseniz README dosyasındaki “Supabase kurulumu” adımlarını ve Vercel ortam
      değişkenlerini kontrol edin.
    </div>
  );
}
