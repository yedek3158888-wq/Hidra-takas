import type { TradeReference } from "@/lib/types";
import { formatDate } from "@/lib/format";
import { publicStorageUrl } from "@/lib/supabase";
import { Icon } from "./Icons";

/** Referansın kaynağı açıkça etiketlenir; kullanıcı beyanı kesin kanıt gibi sunulmaz. */
export function VerificationLabel({ value }: { value: TradeReference["verification"] }) {
  return value === "admin_verified" ? (
    <span className="inline-flex items-center gap-1 rounded-full border border-emerald-400/30 bg-emerald-400/10 px-2.5 py-0.5 text-xs font-medium text-emerald-300">
      <Icon name="check" className="h-3 w-3" /> Yönetici inceledi
    </span>
  ) : (
    <span className="inline-flex items-center rounded-full border border-line bg-surface px-2.5 py-0.5 text-xs text-muted">
      Kullanıcı beyanı
    </span>
  );
}

export function ReferenceCard({ reference }: { reference: TradeReference }) {
  const img = reference.reference_images[0];
  return (
    <article className="card flex flex-col overflow-hidden">
      <div className="aspect-[4/3] overflow-hidden bg-surface">
        {img ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={publicStorageUrl(img.bucket, img.path)}
            alt={reference.title}
            loading="lazy"
            decoding="async"
            className="h-full w-full object-cover"
          />
        ) : (
          <div className="grid h-full w-full place-items-center text-muted">
            <Icon name="image" className="h-9 w-9 opacity-50" />
          </div>
        )}
      </div>
      <div className="flex flex-1 flex-col gap-2 p-4">
        <VerificationLabel value={reference.verification} />
        <h3 className="line-clamp-2 font-semibold leading-snug">{reference.title}</h3>
        {reference.summary ? <p className="line-clamp-3 text-sm text-muted">{reference.summary}</p> : null}
        <p className="mt-auto pt-2 text-xs text-muted">{formatDate(reference.trade_date ?? reference.created_at)}</p>
      </div>
    </article>
  );
}
