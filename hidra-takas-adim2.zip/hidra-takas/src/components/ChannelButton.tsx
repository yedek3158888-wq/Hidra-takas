import type { ChannelInfo } from "@/lib/contact";
import { Icon } from "./Icons";

/**
 * Harici platforma giden bağlantı. Kullanıcıya hangi platforma gideceği açıkça gösterilir.
 * Kanal ayarlanmamışsa çalışıyormuş gibi davranmaz; devre dışı ve açıklamalı görünür.
 */
export function ChannelButton({
  channel,
  label,
  info,
  variant = "ghost",
  prefix,
}: {
  channel: "telegram" | "instagram" | "threads";
  label: string;
  info: ChannelInfo | null;
  variant?: "primary" | "ghost";
  prefix?: string;
}) {
  const text = prefix ? `${prefix}` : label;
  if (!info) {
    return (
      <span className="btn-disabled" role="note" title={`${label} bağlantısı henüz ayarlanmadı`}>
        <Icon name={channel} />
        {text}
        <span className="text-xs font-normal">(yakında)</span>
      </span>
    );
  }
  return (
    <a
      href={info.url}
      target="_blank"
      rel="noopener noreferrer nofollow"
      className={variant === "primary" ? "btn-primary" : "btn-ghost"}
      title={`${info.label} (${info.host}) adresine yönlendirilirsiniz`}
    >
      <Icon name={channel} />
      {text}
      <Icon name="external" className="h-3.5 w-3.5 opacity-70" />
      <span className="sr-only">Harici site: {info.host}</span>
    </a>
  );
}
