import Link from "next/link";
import { NAV_LINKS } from "@/lib/site";
import { Logo } from "./Logo";
import { ChannelButton } from "./ChannelButton";
import type { ChannelInfo } from "@/lib/contact";

export function Header({
  brandName,
  logoUrl,
  telegram,
}: {
  brandName: string;
  logoUrl: string;
  telegram: ChannelInfo | null;
}) {
  return (
    <header className="sticky top-0 z-40 border-b border-line/70 bg-bg/80 backdrop-blur-xl">
      <div className="wrap flex h-16 items-center justify-between gap-4">
        <Logo name={brandName} logoUrl={logoUrl || undefined} />

        <nav aria-label="Ana menü" className="hidden items-center gap-1 md:flex">
          {NAV_LINKS.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className="rounded-lg px-3 py-2 text-sm font-medium text-muted transition hover:bg-surface hover:text-ink"
            >
              {l.label}
            </Link>
          ))}
        </nav>

        <div className="hidden md:block">
          <ChannelButton channel="telegram" label="Telegram" info={telegram} variant="primary" prefix="Telegram" />
        </div>
      </div>
    </header>
  );
}
