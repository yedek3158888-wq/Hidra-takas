# ORJHIDRA MARKET

eFootball hesap takası topluluğu için ilan panosu. **Next.js 15 + TypeScript + Tailwind CSS + Supabase (PostgreSQL) + Vercel.**

> Bu site Konami/eFootball ile bağlantılı değildir. Ödeme, emanet veya hesap devri aracılığı yapmaz.
> Hukuki sayfalar (`/gizlilik`, `/kosullar`, `/telif`) **taslaktır**; yayından önce avukata kontrol ettirin.

## Durum (Adım 2/5 tamam)

| Parça | Durum |
|---|---|
| Veritabanı şeması, RLS, storage kovaları, denetim kaydı | ✅ Yazıldı ve gerçek PostgreSQL'de test edildi (53/53) |
| Koyu tema, mobil alt menü, ana sayfa, Hesaplar listesi, Referanslar listesi, Hakkımızda, İletişim, yasal taslaklar, 404/hata, robots, sitemap | ✅ Yazıldı — **Vercel derlemesiyle ilk kez doğrulanacak** (aşağıya bakın) |
| Giriş / kayıt, ilan detay sayfası, yorum-puan, bildir, paylaş | ⏳ Adım 3–4 |
| Admin paneli (`/admin`), görsel yükleme, 2FA | ⏳ Adım 3 |
| Referans gönderme/onaylama, iletişim formu, hız sınırı | ⏳ Adım 4 |

## 1) Supabase kurulumu (telefondan yapılabilir)

1. supabase.com → **New project**. Veritabanı parolasını bir parola yöneticisine kaydedin.
2. Proje açılınca sol menüden **SQL Editor** → **New query**.
3. `supabase/migrations/0001_init.sql` dosyasının **tamamını** yapıştırıp **Run** deyin. “Success” görmelisiniz.
4. **Project Settings → API** sayfasından iki değeri alın:
   - **Project URL**
   - **anon public** anahtarı (herkese açık anahtardır; yine de `service_role` anahtarını kimseyle paylaşmayın).
5. **Authentication → Providers → Email** açık kalsın. (E-posta doğrulaması varsayılan olarak açıktır; kapatmayın.)

## 2) Vercel'e yayınlama

1. vercel.com → **Add New → Project** → GitHub'daki bu depoyu seçip **Import**.
2. **Environment Variables** bölümüne ekleyin (değerleri `.env.example` dosyasındaki gibi, kendi bilgilerinizle):
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `NEXT_PUBLIC_SITE_URL` (alan adınız bağlanana kadar Vercel'in verdiği `https://...vercel.app` adresi)
3. **Deploy**. Derleme hata verirse hata ekranının görüntüsünü paylaşın.

> Gizli anahtarlar yalnızca Vercel'in ortam değişkenlerinde durur. `NEXT_PUBLIC_` ile başlayanlar tarayıcıya gider; **gizli bir şeyi asla bu önekle eklemeyin.** Kodda ve depoda hiçbir gerçek anahtar yoktur.

## 3) Telegram / Instagram / Threads bağlantıları

Admin paneli Adım 3'te gelecek. Şimdilik Supabase → **SQL Editor** içinde (kullanıcı adınızı yazın):

```sql
update site_settings set value = '"kullanici_adiniz"' where key = 'telegram';
update site_settings set value = '"kullanici_adiniz"' where key = 'instagram';
update site_settings set value = '"kullanici_adiniz"' where key = 'threads';
```

Tam adres de olur (`https://t.me/ad`); yalnızca ilgili platformun alan adlarına izin verilir. Ayar boşsa düğme “yakında” olarak devre dışı görünür, çalışıyormuş gibi davranmaz. Değişiklik en geç ~60 sn içinde görünür.

## 4) Admin hesabı (güvenli yöntem — kodda sabit parola yok)

Giriş sayfası Adım 3'te gelecek. Akış:

1. Sitede kendi e-postanızla normal kullanıcı olarak kayıt olun (rol her zaman `user` başlar).
2. Supabase **SQL Editor**'de bir kez çalıştırın:
   ```sql
   update public.profiles set role = 'admin'
   where id = (select id from auth.users where email = 'sizin@epostaniz.com');
   ```
   Bu yol yalnızca veritabanı sahibinin SQL Editor'ünde çalışır; site üzerinden kimse kendini admin yapamaz (veritabanı tetikleyicisi engeller, test edilmiştir). Sonraki yöneticileri mevcut bir admin verebilir.

## 5) Alan adı ve HTTPS

Vercel → Project → **Settings → Domains** → alan adınızı ekleyin. Vercel size DNS kayıtlarını gösterir (alan adı sağlayıcınızda A/CNAME olarak girilir). HTTPS sertifikası otomatik verilir. Sonra `NEXT_PUBLIC_SITE_URL` değerini alan adınızla güncelleyip yeniden dağıtın; Supabase → Authentication → URL Configuration'da **Site URL**'i de aynı adres yapın.

## 6) Veri saklama kuralları

- İletişim mesajları 90 gün, incelenmiş şikâyetler 180 gün sonra silinir. `purge_old_records()` fonksiyonu hazırdır; Supabase'de **Database → Extensions → pg_cron** açıp günlük çalıştırın:
  `select cron.schedule('purge-old', '0 3 * * *', 'select public.purge_old_records()');`
- Kullanıcı silinirse profili, yorumları ve puanları silinir; referans/ilan kayıtlarındaki kişi bağlantısı boşaltılır (`on delete set null`).
- Ham IP saklanmaz; yalnızca hız sınırı için tuzlanmış özet tutulur (Adım 4).

## Testler

Veritabanı kuralları gerçek PostgreSQL 16 üzerinde test edilir (Supabase'in `auth`/`storage` yapısı taklit edilir):

```bash
PGHOST=localhost PGUSER=postgres bash supabase/tests/run.sh
```

53 kontrol: rol yükseltme engeli, RLS (anon/kullanıcı/admin), yorum spam sınırı, tekrar yorum engeli, referans onay akışı, storage klasör yetkisi, denetim kaydının silinemezliği, banlı kullanıcı vb.

## Bilinen eksikler / dürüst notlar

- **Site kodu henüz derlenmedi.** Geliştirme ortamında npm paket sunucusuna erişim yoktu; kodun sözdizimi ve içe aktarma yolları kontrol edildi, ancak `next build` ilk kez Vercel'de çalışacak. Tip hatası çıkarsa düzeltilecek.
- Ekran görüntüsü/mobil-masaüstü görsel testi henüz yapılmadı (aynı sebep).
- CSP başlığı `'unsafe-inline'` içeriyor (Next.js hidrasyonu için). Nonce tabanlı sıkı CSP planlanan iyileştirmedir.
- İletişim formu, şikâyet, referans gönderme, yorum ve admin paneli sonraki adımlardadır; arayüzde çalışıyormuş gibi gösterilmez.
